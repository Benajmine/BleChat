package com.example.blechat

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaRecorder
import android.os.Build
import java.io.ByteArrayOutputStream
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Live voice for a call. Phone mic -> AMR-NB encoder -> [send]; bytes given to [feed] -> AMR-NB decoder -> speaker.
 * Wire format: repeated [length byte][AMR frame], so it doesn't matter how Bluetooth splits the writes.
 */
class Voice(ctx: Context, private val send: (ByteArray) -> Unit) {
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val rate = 8000
    private val frames = LinkedBlockingQueue<ByteArray>()
    private val rx = ByteArrayOutputStream()
    private var rec: AudioRecord? = null
    private var track: AudioTrack? = null
    private var enc: MediaCodec? = null
    private var dec: MediaCodec? = null
    @Volatile private var running = false
    @Volatile var muted = false
    @Volatile var micLevel = 0   // 0..8, shown on the call screen
    @Volatile var hearLevel = 0
    @Volatile var error = ""

    fun start() {
        if (running) return
        running = true
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        try { startPlayback() } catch (e: Exception) { error = "speaker: " + (e.message ?: e.javaClass.simpleName) }
        try { startMic() } catch (e: Exception) { error = "mic: " + (e.message ?: e.javaClass.simpleName) }
    }

    private fun startPlayback() {
        val minOut = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack(
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build(),
            AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build(),
            maxOf(minOut, 3200), AudioTrack.MODE_STREAM, AudioManager.AUDIO_SESSION_ID_GENERATE)
        track = t
        val d = MediaCodec.createDecoderByType("audio/3gpp")
        d.configure(MediaFormat.createAudioFormat("audio/3gpp", rate, 1), null, null, 0)
        d.start()
        dec = d
        Thread { play(d, t) }.start()
    }

    private fun startMic() {
        val minIn = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, rate, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, maxOf(minIn, 3200))
        rec = r
        if (r.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("microphone unavailable (permission?)")
        val e = MediaCodec.createEncoderByType("audio/3gpp")
        val f = MediaFormat.createAudioFormat("audio/3gpp", rate, 1)
        f.setInteger(MediaFormat.KEY_BIT_RATE, 5900)
        e.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        e.start()
        enc = e
        Thread { capture(e, r) }.start()
    }

    private fun capture(e: MediaCodec, r: AudioRecord) {
        val pcm = ByteArray(320) // 20 ms
        val info = MediaCodec.BufferInfo()
        val pack = ByteArrayOutputStream()
        var n = 0
        try {
            r.startRecording()
            while (running) {
                val got = r.read(pcm, 0, pcm.size)
                if (got <= 0) continue
                if (muted) pcm.fill(0)
                micLevel = level(pcm, got)
                val i = e.dequeueInputBuffer(10_000)
                if (i >= 0) {
                    val b = e.getInputBuffer(i)!!
                    b.clear()
                    b.put(pcm, 0, got)
                    e.queueInputBuffer(i, 0, got, System.nanoTime() / 1000, 0)
                }
                while (true) {
                    val o = e.dequeueOutputBuffer(info, 0)
                    if (o < 0) break
                    if (info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        val f = ByteArray(info.size)
                        val ob = e.getOutputBuffer(o)!!
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        ob.get(f)
                        pack.write(f.size)
                        pack.write(f, 0, f.size)
                        n++
                    }
                    e.releaseOutputBuffer(o, false)
                }
                if (n >= 3) { send(pack.toByteArray()); pack.reset(); n = 0 } // ~60 ms per Bluetooth write
            }
        } catch (x: Exception) { if (running) error = "mic: " + (x.message ?: "stopped") }
    }

    private fun play(d: MediaCodec, t: AudioTrack) {
        val info = MediaCodec.BufferInfo()
        val out = ByteArray(4096)
        try {
            t.play()
            while (running) {
                val f = frames.poll(40, TimeUnit.MILLISECONDS)
                if (f == null) hearLevel = 0
                else {
                    val i = d.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val b = d.getInputBuffer(i)!!
                        b.clear()
                        b.put(f)
                        d.queueInputBuffer(i, 0, f.size, System.nanoTime() / 1000, 0)
                    }
                }
                while (true) {
                    val o = d.dequeueOutputBuffer(info, 0)
                    if (o < 0) break
                    if (info.size > 0) {
                        val ob = d.getOutputBuffer(o)!!
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        val n = minOf(info.size, out.size)
                        ob.get(out, 0, n)
                        hearLevel = level(out, n)
                        t.write(out, 0, n)
                    }
                    d.releaseOutputBuffer(o, false)
                }
            }
        } catch (x: Exception) { if (running) error = "speaker: " + (x.message ?: "stopped") }
    }

    /** Bytes arriving from the other phone (any split). */
    fun feed(b: ByteArray) {
        synchronized(rx) {
            rx.write(b, 0, b.size)
            val all = rx.toByteArray()
            var p = 0
            while (p < all.size) {
                val len = all[p].toInt() and 0xFF
                if (p + 1 + len > all.size) break
                if (len > 0) frames.offer(all.copyOfRange(p + 1, p + 1 + len))
                p += 1 + len
            }
            rx.reset()
            rx.write(all, p, all.size - p)
        }
        if (frames.size > 40) frames.clear() // keep the delay bounded
    }

    private fun level(b: ByteArray, n: Int): Int {
        var sum = 0.0
        var i = 0
        while (i + 1 < n) {
            val s = (b[i].toInt() and 0xFF) or (b[i + 1].toInt() shl 8)
            sum += s.toDouble() * s
            i += 2
        }
        return minOf(8, (Math.sqrt(sum / maxOf(1, n / 2)) / 400).toInt())
    }

    /** kind: "earpiece", "speaker" or "headset". The mic is picked automatically to match. */
    @Suppress("DEPRECATION")
    fun route(kind: String) {
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        if (Build.VERSION.SDK_INT >= 31) {
            val want = when (kind) {
                "speaker" -> setOf(AudioDeviceInfo.TYPE_BUILTIN_SPEAKER)
                "headset" -> setOf(AudioDeviceInfo.TYPE_BLUETOOTH_SCO, AudioDeviceInfo.TYPE_BLE_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADSET,
                    AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_USB_HEADSET)
                else -> setOf(AudioDeviceInfo.TYPE_BUILTIN_EARPIECE)
            }
            val dev = am.availableCommunicationDevices.firstOrNull { it.type in want }
            if (dev != null) am.setCommunicationDevice(dev)
        } else {
            am.isSpeakerphoneOn = kind == "speaker"
            if (kind == "headset") { am.startBluetoothSco(); am.isBluetoothScoOn = true }
            else { am.stopBluetoothSco(); am.isBluetoothScoOn = false }
        }
    }

    fun hasHeadset(): Boolean {
        if (Build.VERSION.SDK_INT < 23) return false
        val types = setOf(AudioDeviceInfo.TYPE_BLUETOOTH_SCO, AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_WIRED_HEADSET,
            AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_USB_HEADSET)
        return am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { it.type in types }
    }

    @Suppress("DEPRECATION")
    fun stop() {
        running = false
        try { rec?.stop() } catch (e: Exception) { }
        try { rec?.release() } catch (e: Exception) { }
        try { track?.stop() } catch (e: Exception) { }
        try { track?.release() } catch (e: Exception) { }
        try { enc?.stop(); enc?.release() } catch (e: Exception) { }
        try { dec?.stop(); dec?.release() } catch (e: Exception) { }
        rec = null; track = null; enc = null; dec = null
        try {
            if (Build.VERSION.SDK_INT >= 31) am.clearCommunicationDevice()
            else { am.isSpeakerphoneOn = false; am.stopBluetoothSco() }
        } catch (e: Exception) { }
        am.mode = AudioManager.MODE_NORMAL
    }
}
