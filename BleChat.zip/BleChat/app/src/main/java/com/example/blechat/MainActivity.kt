package com.example.blechat

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.ParcelUuid
import android.os.SystemClock
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.inputmethod.EditorInfo
import android.widget.*
import java.io.ByteArrayOutputStream
import java.util.UUID

// Protocol: every phone runs a GATT server with one write-only "inbox" characteristic
// and advertises SERVICE. To send, connect to a nearby phone and write the UTF-8 text
// in 19-byte chunks (fits the default 20-byte BLE payload). Byte 0 of each write is
// 0 = more chunks follow, 1 = last chunk.
private val SERVICE: UUID = UUID.fromString("7b1f0001-0c3a-4e57-9f6d-2a5e8c1d4b90")
private val INBOX: UUID = UUID.fromString("7b1f0002-0c3a-4e57-9f6d-2a5e8c1d4b90")
private const val CHUNK = 19
private const val FRESH_MS = 20_000L // ignore phones not heard from in this long

@SuppressLint("MissingPermission")
class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private var adapter: BluetoothAdapter? = null
    private var server: BluetoothGattServer? = null
    private val peers = HashMap<String, Pair<BluetoothDevice, Long>>() // address -> (phone, last seen)
    private val partial = HashMap<String, ByteArrayOutputStream>()     // messages being assembled

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val density = resources.displayMetrics.density
        fun dp(n: Int) = (n * density).toInt()

        status = TextView(this)
        log = TextView(this).apply { textSize = 16f }
        scroll = ScrollView(this).apply { addView(log) }
        input = EditText(this).apply {
            hint = "Message"
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, _, _ -> send(); true }
        }
        val sendBtn = Button(this).apply { text = "Send"; setOnClickListener { send() } }
        val row = LinearLayout(this).apply {
            addView(input, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(sendBtn)
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(12))
            addView(status)
            addView(scroll, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
            addView(row)
        })

        val need = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_ADVERTISE, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (need.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) start()
        else requestPermissions(need, 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) start()
        else status.text = "Bluetooth permission is off. Allow it in Settings, then reopen the app."
    }

    private fun start() {
        val mgr = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val a = mgr.adapter
        if (a == null || !a.isEnabled) { status.text = "Bluetooth is off. Turn it on, then reopen the app."; return }
        adapter = a

        // Receive: GATT server with a write-only inbox. Advertising starts in onServiceAdded.
        server = mgr.openGattServer(this, serverCb)
        val svc = BluetoothGattService(SERVICE, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        svc.addCharacteristic(BluetoothGattCharacteristic(
            INBOX, BluetoothGattCharacteristic.PROPERTY_WRITE, BluetoothGattCharacteristic.PERMISSION_WRITE))
        server?.addService(svc)

        // Discover: scan for other phones advertising SERVICE.
        a.bluetoothLeScanner?.startScan(
            listOf(ScanFilter.Builder().setServiceUuid(ParcelUuid(SERVICE)).build()),
            ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(),
            scanCb)
        ticker.run()
    }

    private fun advertise() {
        val adv = adapter?.bluetoothLeAdvertiser
        if (adv == null) { show("This phone can't advertise over Bluetooth LE, so others can't send to it."); return }
        adv.startAdvertising(
            AdvertiseSettings.Builder()
                .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
                .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
                .setConnectable(true).build(),
            AdvertiseData.Builder().setIncludeDeviceName(false).addServiceUuid(ParcelUuid(SERVICE)).build(),
            advCb)
    }

    private val advCb = object : AdvertiseCallback() {
        override fun onStartFailure(code: Int) { runOnUiThread { show("Advertising failed (code $code). Turn Bluetooth off and on, then reopen the app.") } }
    }

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(type: Int, r: ScanResult) {
            peers[r.device.address] = r.device to SystemClock.elapsedRealtime()
        }
        override fun onScanFailed(code: Int) { runOnUiThread { show("Scan failed (code $code). Turn Bluetooth off and on, then reopen the app.") } }
    }

    private val serverCb = object : BluetoothGattServerCallback() {
        override fun onServiceAdded(s: Int, svc: BluetoothGattService?) { runOnUiThread { advertise() } }

        override fun onCharacteristicWriteRequest(
            d: BluetoothDevice, id: Int, c: BluetoothGattCharacteristic,
            prepared: Boolean, needsResponse: Boolean, offset: Int, v: ByteArray
        ) {
            if (needsResponse) server?.sendResponse(d, id, BluetoothGatt.GATT_SUCCESS, offset, v)
            if (v.isEmpty()) return
            runOnUiThread {
                val buf = partial.getOrPut(d.address) { ByteArrayOutputStream() }
                buf.write(v, 1, v.size - 1)
                if (v[0].toInt() == 1) { show(buf.toString("UTF-8")); partial.remove(d.address) }
            }
        }
    }

    private fun send() {
        val text = input.text.toString().trim().take(300)
        if (text.isEmpty()) return
        val now = SystemClock.elapsedRealtime()
        val targets = peers.values.filter { now - it.second < FRESH_MS }.map { it.first }
        if (targets.isEmpty()) { show("No one nearby yet. Open the app on the other phone and wait a few seconds."); return }
        input.setText("")
        show("Me: $text")
        val data = "${Build.MODEL}: $text".toByteArray()
        targets.forEach { Sender(it, data) }
    }

    // One short-lived connection per message per phone: connect, write chunks, disconnect.
    private inner class Sender(dev: BluetoothDevice, private val data: ByteArray) : BluetoothGattCallback() {
        private var pos = 0
        private var ok = false
        private var chr: BluetoothGattCharacteristic? = null

        init { dev.connectGatt(this@MainActivity, false, this, BluetoothDevice.TRANSPORT_LE) }

        override fun onConnectionStateChange(g: BluetoothGatt, st: Int, state: Int) {
            if (state == BluetoothProfile.STATE_CONNECTED) g.discoverServices()
            else if (state == BluetoothProfile.STATE_DISCONNECTED) {
                g.close()
                runOnUiThread { show(if (ok) "✓ Delivered" else "✗ Not delivered. Move closer and try again.") }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, st: Int) {
            chr = g.getService(SERVICE)?.getCharacteristic(INBOX)
            if (chr == null) g.disconnect() else write(g)
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, st: Int) {
            if (st != BluetoothGatt.GATT_SUCCESS) g.disconnect()
            else if (pos >= data.size) { ok = true; g.disconnect() }
            else write(g)
        }

        private fun write(g: BluetoothGatt) {
            val end = minOf(pos + CHUNK, data.size)
            val chunk = byteArrayOf((if (end == data.size) 1 else 0).toByte()) + data.copyOfRange(pos, end)
            pos = end
            val c = chr!!
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(c, chunk, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT)
            } else {
                c.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                c.value = chunk
                g.writeCharacteristic(c)
            }
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            val now = SystemClock.elapsedRealtime()
            val n = peers.values.count { now - it.second < FRESH_MS }
            status.text = if (n == 0) "Searching for nearby phones…" else "$n ${if (n == 1) "phone" else "phones"} nearby"
            status.postDelayed(this, 2000)
        }
    }

    private fun show(s: String) {
        log.append(s + "\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    override fun onDestroy() {
        super.onDestroy()
        status.removeCallbacks(ticker)
        adapter?.bluetoothLeScanner?.stopScan(scanCb)
        adapter?.bluetoothLeAdvertiser?.stopAdvertising(advCb)
        server?.close()
    }
}
