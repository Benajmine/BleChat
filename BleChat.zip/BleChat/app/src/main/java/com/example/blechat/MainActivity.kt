package com.example.blechat

import android.Manifest
import android.app.Activity
import android.app.Dialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.location.LocationManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.text.InputFilter
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextPaint
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.Window
import android.view.inputmethod.EditorInfo
import android.widget.*
import java.io.File

private val BG = Color.parseColor("#050805")
private val GREEN = Color.parseColor("#00FF41")
private val DIM = Color.parseColor("#1FA83C")
private val RED = Color.parseColor("#FF4D4D")

/** A button in a themed dialog. */
class Act(val label: String, val fn: () -> Unit)

class MainActivity : Activity() {
    private lateinit var who: TextView
    private lateinit var status: TextView
    private lateinit var keep: CheckBox
    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var toBtn: Button
    private lateinit var micBtn: Button
    private lateinit var callBtn: Button
    private var callDlg: Dialog? = null
    private var callDlgFor = "" // call id of the incoming-call popup on screen
    private var toKey: String? = null // null = everyone nearby
    private var toLabel = "Everyone nearby"
    private var shown = -1            // Store.version last drawn
    private var notice = ""           // short message shown in red in the status line
    private var noticeUntil = 0L
    private var rec: MediaRecorder? = null
    private var recStart = 0L
    private var player: MediaPlayer? = null
    private val ui = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() { render(); ui.postDelayed(this, 2000) }
    }

    // ---- terminal-style building blocks -----------------------------------------------------

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun txt(size: Float, color: Int) =
        TextView(this).apply { textSize = size; setTextColor(color); typeface = Typeface.MONOSPACE }

    private fun frame() = GradientDrawable().apply { setColor(BG); setStroke(dp(1), GREEN); cornerRadius = dp(3).toFloat() }

    private fun btn(label: String, click: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        typeface = Typeface.MONOSPACE
        setTextColor(GREEN)
        background = frame()
        stateListAnimator = null
        setOnClickListener { click() }
    }

    /** Every popup in the app goes through here so it matches the theme. */
    private fun dlg(title: String, body: View?, vararg actions: Act): Dialog {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(10))
            background = frame()
        }
        box.addView(txt(15f, GREEN).apply { text = "> $title"; setTypeface(Typeface.MONOSPACE, Typeface.BOLD) })
        if (body != null) {
            box.addView(body, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(10) })
        }
        if (actions.isNotEmpty()) {
            val bar = LinearLayout(this).apply { gravity = Gravity.END }
            for (a in actions) {
                bar.addView(btn(a.label) { d.dismiss(); a.fn() },
                    LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(8) })
            }
            box.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(12) })
        }
        d.setContentView(box)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.9).toInt(), WRAP_CONTENT)
        d.show()
        return d
    }

    private fun say(m: String) { notice = m; noticeUntil = SystemClock.elapsedRealtime() + 6000; render() }

    // ---- lifecycle --------------------------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27 && BleService.inst?.callState == 2) { setShowWhenLocked(true); setTurnScreenOn(true) }
        window.statusBarColor = BG
        window.navigationBarColor = BG
        who = txt(16f, GREEN).apply { setOnClickListener { askName() } }
        status = txt(13f, DIM)
        keep = CheckBox(this).apply {
            text = "auto-enable bluetooth"
            typeface = Typeface.MONOSPACE
            setTextColor(DIM)
            buttonTintList = ColorStateList.valueOf(GREEN)
            isChecked = Store.keepOn(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Store.setKeepOn(this@MainActivity, on) }
        }
        log = txt(15f, GREEN).apply { movementMethod = LinkMovementMethod.getInstance(); highlightColor = Color.TRANSPARENT }
        scroll = ScrollView(this).apply { addView(log); setPadding(0, dp(8), 0, dp(8)) }
        toBtn = btn("") { pickTarget() }
        input = EditText(this).apply {
            hint = "type message..."
            setHintTextColor(DIM)
            setTextColor(GREEN)
            typeface = Typeface.MONOSPACE
            background = null
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, _, _ -> send(); true }
        }
        micBtn = btn("mic") {}
        callBtn = btn("call") { callOrHangUp() }
        micBtn.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { v.isPressed = true; startRec() }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.isPressed = false; stopRec() }
            }
            true
        }
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(txt(16f, GREEN).apply { text = "> " })
            addView(input, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(btn("send") { send() })
            addView(micBtn)
        }
        val sel = LinearLayout(this).apply {
            addView(toBtn, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(callBtn)
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(16), dp(24), dp(16), dp(12))
            addView(txt(22f, GREEN).apply { text = "LOCAL//LINK_"; setTypeface(Typeface.MONOSPACE, Typeface.BOLD) })
            addView(txt(11f, DIM).apply { text = "// bluetooth only. no internet. no servers." })
            addView(who)
            addView(status)
            addView(keep)
            addView(scroll, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
            addView(sel)
            addView(row)
        })
        if (Store.hasName(this)) askPermissions() else askName(true)
    }

    override fun onStart() {
        super.onStart()
        BleService.uiVisible = true
        BleService.onUpdate = { render() }
        BleService.inst?.rescan()
        go()
        ui.postDelayed({ checkBluetooth() }, 2500)
        ui.post(ticker)
    }

    override fun onStop() {
        super.onStop()
        BleService.uiVisible = false
        BleService.onUpdate = null
        BleService.inst?.rescan()
        ui.removeCallbacksAndMessages(null)
        rec?.let { try { it.stop() } catch (e: RuntimeException) { }; it.release() }
        rec = null
        player?.release()
        player = null
    }

    // ---- name -------------------------------------------------------------------------------

    private fun askName(first: Boolean = false) {
        val et = EditText(this).apply {
            setText(Store.name(this@MainActivity))
            setSelection(text.length)
            setSingleLine()
            filters = arrayOf<InputFilter>(InputFilter.LengthFilter(12))
            setTextColor(GREEN)
            typeface = Typeface.MONOSPACE
            background = frame()
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(txt(12f, DIM).apply { text = "Other phones will see this name on your messages." })
            addView(et, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) })
        }
        dlg("your name", body, Act("save") {
            Store.setName(this, et.text.toString())
            BleService.inst?.readvertise()
            render()
            if (first) askPermissions()
        }).setCancelable(false)
    }

    // ---- permissions and service ------------------------------------------------------------

    private fun perms(): Array<String> {
        val l = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            l.add(Manifest.permission.BLUETOOTH_SCAN)
            l.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            l.add(Manifest.permission.BLUETOOTH_CONNECT)
        } else if (Build.VERSION.SDK_INT >= 23) {
            l.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l.toTypedArray()
    }

    private fun btGranted() = Build.VERSION.SDK_INT < 23 ||
        perms().filter { it != Manifest.permission.POST_NOTIFICATIONS }
            .all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun askPermissions() {
        if (Build.VERSION.SDK_INT >= 23 && perms().any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED })
            requestPermissions(perms(), 1)
        else go()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        if (requestCode == 2) { // microphone
            say(if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) "Microphone allowed. Hold the mic button to talk."
            else "Microphone is off. Allow it in Settings to send voice.")
            return
        }
        if (btGranted()) go()
        else status.text = "Bluetooth permission is off. Allow it in Settings, then reopen the app."
    }

    private fun go() {
        if (!btGranted()) return
        val i = Intent(this, BleService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        askBattery()
    }

    private fun askBattery() {
        if (Build.VERSION.SDK_INT < 23) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val prefs = getSharedPreferences("chat", MODE_PRIVATE)
        if (pm.isIgnoringBatteryOptimizations(packageName) || prefs.getBoolean("askedBattery", false)) return
        prefs.edit().putBoolean("askedBattery", true).apply()
        dlg("run in background",
            txt(13f, GREEN).apply { text = "Android may stop Local Link in the background. On the next screen, tap Allow to get messages when the app is closed." },
            Act("not now") {},
            Act("continue") {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            })
    }

    /** If Bluetooth is still off (the app couldn't switch it on silently), show Android's one-tap "turn on" prompt. */
    private fun checkBluetooth() {
        if (!BleService.uiVisible || !btGranted() || !Store.keepOn(this)) return
        val a = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (a != null && !a.isEnabled) startActivityForResult(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), 3)
    }

    // ---- sending ----------------------------------------------------------------------------

    private fun pickTarget() {
        Store.load(this)
        val near = BleService.inst?.nearby()?.map { it.id }?.toSet() ?: emptySet()
        val ids = Store.known.keys.sortedByDescending { it in near }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        lateinit var d: Dialog
        fun row(label: String, key: String?, name: String) {
            list.addView(txt(15f, GREEN).apply {
                text = label
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { toKey = key; toLabel = name; d.dismiss(); render() }
            })
        }
        row("* Everyone nearby", null, "Everyone nearby")
        ids.forEach { row((if (it in near) "● " else "○ ") + Store.known[it], it, Store.known[it] ?: "?") }
        d = dlg("send to  (● here, ○ out of range)", ScrollView(this).apply { addView(list) })
    }

    private fun send() {
        val text = input.text.toString().trim().take(300)
        if (text.isEmpty()) return
        val s = BleService.inst
        if (s == null) { say("Still starting. Try again in a moment."); return }
        val err = s.send(toKey, toLabel, text)
        if (err != null) say(err) else input.setText("")
    }

    // ---- voice: hold the mic button, release to send ----------------------------------------

    @Suppress("DEPRECATION")
    private fun startRec() {
        if (toKey == null) { say("Pick a person in the To: button first. Voice goes to one person."); return }
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
            return
        }
        try {
            rec = (if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()).apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.AMR_NB)
                setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
                setAudioSamplingRate(8000)
                setAudioEncodingBitRate(5900)
                setMaxDuration(10_000)
                setOutputFile(File(cacheDir, "rec.amr").path)
                prepare()
                start()
            }
            recStart = SystemClock.elapsedRealtime()
            micBtn.text = "● rec"
            micBtn.setTextColor(RED)
        } catch (e: Exception) {
            rec?.release()
            rec = null
            say("Couldn't start the microphone.")
        }
    }

    private fun stopRec() {
        val r = rec ?: return
        rec = null
        micBtn.text = "mic"
        micBtn.setTextColor(GREEN)
        val ms = SystemClock.elapsedRealtime() - recStart
        try { r.stop() } catch (e: RuntimeException) { }
        r.release()
        val key = toKey ?: return
        if (ms < 700) { say("Hold the mic button while you talk."); return }
        val s = BleService.inst
        if (s == null) { say("Still starting. Try again in a moment."); return }
        val bytes = File(cacheDir, "rec.amr").readBytes()
        if (bytes.size < 100) { say("Nothing was recorded. Try again."); return }
        s.sendVoice(key, toLabel, bytes)
    }

    private fun play(id: String) {
        val f = Store.voice(this, id)
        if (!f.exists()) { say("Voice file not found."); return }
        player?.release()
        player = try {
            MediaPlayer().apply {
                setDataSource(f.path)
                prepare()
                setOnCompletionListener { it.release(); if (player === it) player = null }
                start()
            }
        } catch (e: Exception) { say("Couldn't play it."); null }
    }

    // ---- screen -----------------------------------------------------------------------------

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        render()
    }

    private fun callOrHangUp() {
        val s = BleService.inst
        if (s == null) { say("Still starting. Try again in a moment."); return }
        if (s.callState != 0) { s.hangUp(); return }
        val key = toKey
        if (key == null) { say("Pick a person in the To: button first."); return }
        val err = s.startCall(key, toLabel)
        if (err != null) say(err)
    }

    /** Shows the incoming-call popup while this phone rings, and lets the app appear over the lock screen only then. */
    private fun syncCallUi() {
        val s = BleService.inst
        val ringing = s != null && s.callState == 2
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(ringing); setTurnScreenOn(ringing) }
        val want = if (s != null && ringing) s.callId else ""
        if (want == callDlgFor) return
        callDlg?.dismiss()
        callDlg = null
        callDlgFor = want
        if (s != null && want.isNotEmpty()) {
            callDlg = dlg("incoming call", txt(18f, GREEN).apply { text = "☎  ${s.callPeerName} is calling..." },
                Act("decline") { s.hangUp() }, Act("answer") { s.answer() })
            callDlg?.setCancelable(false)
        }
    }

    private fun locationOff(): Boolean {
        if (Build.VERSION.SDK_INT !in 23..30) return false // only Android 6 to 11 need Location for BLE scans
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return !lm.isProviderEnabled(LocationManager.GPS_PROVIDER) && !lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    }

    private fun render() {
        Store.load(this)
        val s = BleService.inst
        val n = s?.nearby()?.size ?: 0
        who.text = "login: ${Store.name(this)}  [edit]"
        val (msg, color) = when {
            SystemClock.elapsedRealtime() < noticeUntil -> "[!] $notice" to RED
            locationOff() -> "[!] Turn on Location. Android 6 to 11 needs it to find nearby Bluetooth devices." to RED
            s == null -> "[*] starting..." to DIM
            s.warning.isNotEmpty() -> "[!] ${s.warning}" to RED
            s.callState == 1 -> "[*] calling ${s.callPeerName}..." to GREEN
            s.callState == 2 -> "[!] ${s.callPeerName} is calling..." to GREEN
            s.callState == 3 -> "[+] in call with ${s.callPeerName}. Hold mic to talk." to GREEN
            n == 0 -> "[*] scanning for nearby phones..." to DIM
            else -> "[+] $n ${if (n == 1) "phone" else "phones"} nearby" to GREEN
        }
        status.text = msg
        status.setTextColor(color)
        callBtn.text = if (s != null && s.callState != 0) "hang up" else "call"
        callBtn.setTextColor(if (s != null && s.callState != 0) RED else GREEN)
        if (s != null && s.callState == 3 && toKey != s.callPeerId) { toKey = s.callPeerId; toLabel = s.callPeerName }
        syncCallUi()
        toBtn.text = "to: $toLabel ▾"
        if (shown != Store.version) {
            shown = Store.version
            val sb = SpannableStringBuilder()
            for (l in Store.lines) {
                val vi = l.indexOf('\u0002') // voice lines end with \u0002<id>
                val line = if (vi >= 0) l.substring(0, vi) + "  ▶ play" else l
                val c = when {
                    l.startsWith("✗") -> RED
                    l.startsWith("Me →") || l.startsWith("✓") || l.startsWith("⏳") -> DIM
                    else -> GREEN
                }
                val start = sb.length
                sb.append(line).append('\n')
                sb.setSpan(ForegroundColorSpan(c), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                if (vi >= 0) {
                    val vid = l.substring(vi + 1)
                    sb.setSpan(object : ClickableSpan() {
                        override fun onClick(w: View) { play(vid) }
                        override fun updateDrawState(ds: TextPaint) { ds.isUnderlineText = true }
                    }, start, sb.length - 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
            log.text = sb
            scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }
}
