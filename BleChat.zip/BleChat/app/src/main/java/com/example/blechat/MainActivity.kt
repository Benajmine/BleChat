package com.example.blechat

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputFilter
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.inputmethod.EditorInfo
import android.widget.*

class MainActivity : Activity() {
    private lateinit var who: TextView
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var toBtn: Button
    private var toKey: String? = null // null = everyone nearby
    private var toLabel = "Everyone nearby"
    private var shown = -1            // Store.version last drawn
    private val ui = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() { render(); ui.postDelayed(this, 2000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val density = resources.displayMetrics.density
        fun dp(n: Int) = (n * density).toInt()
        who = TextView(this).apply { textSize = 18f; setOnClickListener { askName() } }
        status = TextView(this)
        log = TextView(this).apply { textSize = 16f }
        scroll = ScrollView(this).apply { addView(log) }
        toBtn = Button(this).apply { setOnClickListener { pickTarget() } }
        input = EditText(this).apply {
            hint = "Message"
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, _, _ -> send(); true }
        }
        val sendBtn = Button(this).apply { text = "Send"; setOnClickListener { send() } }
        val row = LinearLayout(this).apply {
            addView(input, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(sendBtn)
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(12))
            addView(who)
            addView(status)
            addView(scroll, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
            addView(toBtn)
            addView(row)
        })
        if (Store.hasName(this)) askPermissions() else askName(true)
    }

    override fun onStart() {
        super.onStart()
        BleService.uiVisible = true
        BleService.onUpdate = { render() }
        BleService.inst?.setScanning(true)
        go()
        ui.post(ticker)
    }

    override fun onStop() {
        super.onStop()
        BleService.uiVisible = false
        BleService.onUpdate = null
        BleService.inst?.setScanning(false)
        ui.removeCallbacks(ticker)
    }

    // ---- name -------------------------------------------------------------------------------

    private fun askName(first: Boolean = false) {
        val et = EditText(this).apply {
            setText(Store.name(this@MainActivity))
            setSelection(text.length)
            setSingleLine()
            filters = arrayOf<InputFilter>(InputFilter.LengthFilter(12))
        }
        AlertDialog.Builder(this)
            .setTitle("Your name")
            .setMessage("Other phones will see this name on your messages.")
            .setView(et)
            .setCancelable(false)
            .setPositiveButton("Save") { _, _ ->
                Store.setName(this, et.text.toString())
                BleService.inst?.readvertise()
                render()
                if (first) askPermissions()
            }
            .show()
    }

    // ---- permissions and service ------------------------------------------------------------

    private fun perms(): Array<String> {
        val l = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            l.add(Manifest.permission.BLUETOOTH_SCAN)
            l.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            l.add(Manifest.permission.BLUETOOTH_CONNECT)
        } else if (Build.VERSION.SDK_INT >= 23) {
            l.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l.toTypedArray()
    }

    private fun btGranted() = Build.VERSION.SDK_INT < 23 ||
        perms().filter { it != Manifest.permission.POST_NOTIFICATIONS }
            .all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun askPermissions() {
        if (Build.VERSION.SDK_INT >= 23 && perms().any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED })
            requestPermissions(perms(), 1)
        else go()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        if (btGranted()) go()
        else status.text = "Bluetooth permission is off. Allow it in Settings, then reopen the app."
    }

    private fun go() {
        if (!btGranted()) return
        val i = Intent(this, BleService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        askBattery()
    }

    private fun askBattery() {
        if (Build.VERSION.SDK_INT < 23) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val prefs = getSharedPreferences("chat", MODE_PRIVATE)
        if (pm.isIgnoringBatteryOptimizations(packageName) || prefs.getBoolean("askedBattery", false)) return
        prefs.edit().putBoolean("askedBattery", true).apply()
        AlertDialog.Builder(this)
            .setTitle("Get messages when the app is closed")
            .setMessage("Android may stop BLE Chat in the background. On the next screen, tap Allow.")
            .setPositiveButton("Continue") { _, _ ->
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            }
            .setNegativeButton("Not now", null)
            .show()
    }

    // ---- sending ----------------------------------------------------------------------------

    private fun pickTarget() {
        val peers = BleService.inst?.nearby() ?: emptyList()
        val names = arrayOf("Everyone nearby") + peers.map { it.label() }
        AlertDialog.Builder(this).setTitle("Send to").setItems(names) { _, i ->
            if (i == 0) { toKey = null; toLabel = names[0] } else { toKey = peers[i - 1].key(); toLabel = names[i] }
            render()
        }.show()
    }

    private fun send() {
        val text = input.text.toString().trim().take(300)
        if (text.isEmpty()) return
        val s = BleService.inst
        if (s == null) { toast("Still starting. Try again in a moment."); return }
        val err = s.send(toKey, toLabel, text)
        if (err != null) toast(err) else input.setText("")
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    // ---- screen -----------------------------------------------------------------------------

    private fun locationOff(): Boolean {
        if (Build.VERSION.SDK_INT !in 23..30) return false // only Android 6 to 11 need Location for BLE scans
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return !lm.isProviderEnabled(LocationManager.GPS_PROVIDER) && !lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    }

    private fun render() {
        Store.load(this)
        val s = BleService.inst
        who.text = "You: ${Store.name(this)}  ✎"
        status.text = when {
            locationOff() -> "Turn on Location. Android 6 to 11 needs it to find nearby Bluetooth devices."
            s == null -> "Starting…"
            s.warning.isNotEmpty() -> s.warning
            else -> s.nearby().size.let { n ->
                if (n == 0) "Searching for nearby phones…" else "$n ${if (n == 1) "phone" else "phones"} nearby"
            }
        }
        toBtn.text = "To: $toLabel ▾"
        if (shown != Store.version) {
            shown = Store.version
            log.text = Store.lines.joinToString("\n")
            scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }
}
