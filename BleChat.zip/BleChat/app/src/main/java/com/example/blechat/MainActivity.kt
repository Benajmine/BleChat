package com.example.blechat

import android.Manifest
import android.app.Activity
import android.app.Dialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.location.LocationManager
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.text.InputFilter
import android.text.TextUtils
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextPaint
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.*
import java.io.File

private val BG = Color.parseColor("#050805")
private val GREEN = Color.parseColor("#00FF41")   // accent: brand, primary actions
private val TEXT = Color.parseColor("#C4F8CF")    // message text, softer than the accent
private val DIM = Color.parseColor("#3E9B53")     // meta text
private val RED = Color.parseColor("#FF5C5C")
private val PANEL = Color.parseColor("#0B170E")   // incoming bubbles, composer, popups
private val PANEL2 = Color.parseColor("#12301A")  // outgoing bubbles, buttons

/** Terminal-style dash cursor: a short bar sitting on the baseline of the line. */
private class DashCursor(private val w: Int, private val h: Int) : Drawable() {
    private val paint = Paint().apply { color = GREEN }
    override fun draw(c: Canvas) {
        val b = bounds
        c.drawRect(b.left.toFloat(), (b.bottom - h).toFloat(), (b.left + w).toFloat(), b.bottom.toFloat(), paint)
    }
    override fun getIntrinsicWidth() = w
    override fun setAlpha(a: Int) { paint.alpha = a }
    override fun setColorFilter(f: ColorFilter?) { paint.colorFilter = f }
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}

/** A button in a themed dialog. */
class Act(val label: String, val fn: () -> Unit)

class MainActivity : Activity() {
    private lateinit var who: TextView
    private lateinit var status: TextView
    private lateinit var keep: CheckBox
    private lateinit var chat: LinearLayout
    private lateinit var empty: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var toBtn: Button
    private lateinit var micBtn: Button
    private lateinit var callBtn: Button
    private lateinit var dash: TextView
    private lateinit var callUi: LinearLayout
    private lateinit var cAvatar: TextView
    private lateinit var cName: TextView
    private lateinit var cState: TextView
    private lateinit var cLink: TextView
    private lateinit var cLevels: TextView
    private lateinit var cInput: TextView
    private lateinit var cRoutes: LinearLayout
    private lateinit var cMute: Button
    private lateinit var cEnd: Button
    private lateinit var cAnswer: Button
    private lateinit var cDecline: Button
    private var callStart = 0L
    private var lastRoute = ""
    private var pendingCall = false
    private var pendingAnswer = false
    private var callDlg: Dialog? = null
    private var callDlgFor = "" // call id of the incoming-call popup on screen
    private var toKey: String? = null // null = everyone nearby
    private var toLabel = "Everyone nearby"
    private var drawn = 0 // Store.total lines already on screen
    private var notice = ""           // short message shown in red in the status line
    private var noticeUntil = 0L
    private var rec: MediaRecorder? = null
    private var recStart = 0L
    private var player: MediaPlayer? = null
    private val ui = Handler(Looper.getMainLooper())
    private val blink = object : Runnable {
        override fun run() {
            dash.visibility = if (dash.visibility == View.VISIBLE) View.INVISIBLE else View.VISIBLE
            ui.postDelayed(this, 530)
        }
    }
    private val callTick = object : Runnable {
        override fun run() {
            if ((BleService.inst?.callState ?: 0) != 0) syncCallUi()
            ui.postDelayed(this, 400)
        }
    }
    private val ticker = object : Runnable {
        override fun run() { render(); ui.postDelayed(this, 2000) }
    }

    // ---- building blocks: tonal panels instead of outlines ---------------------------------

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun txt(size: Float, color: Int) =
        TextView(this).apply { textSize = size; setTextColor(color); typeface = Typeface.MONOSPACE }

    private fun shape(fill: Int, radius: Int) = GradientDrawable().apply { setColor(fill); cornerRadius = dp(radius).toFloat() }

    /** Filled shape with a soft green ripple when touched. */
    private fun tap(fill: Int, radius: Int): Drawable =
        RippleDrawable(ColorStateList.valueOf(0x4000FF41), shape(fill, radius), shape(Color.WHITE, radius))

    private fun frame() = shape(PANEL2, 10)

    private fun btn(label: String, primary: Boolean = false, click: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        typeface = if (primary) Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) else Typeface.MONOSPACE
        textSize = 14f
        setTextColor(if (primary) BG else GREEN)
        background = tap(if (primary) GREEN else PANEL2, 22)
        stateListAnimator = null
        minWidth = 0
        minHeight = 0
        minimumWidth = 0
        minimumHeight = 0
        setPadding(dp(16), dp(10), dp(16), dp(10))
        setOnClickListener { click() }
    }

    /** Every popup goes through here so it matches the theme. The last button is the main action. */
    private fun dlg(title: String, body: View?, vararg actions: Act): Dialog {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(14))
            background = shape(PANEL, 18)
        }
        box.addView(txt(11f, DIM).apply { text = title.uppercase(); letterSpacing = 0.12f })
        if (body != null) {
            box.addView(body, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(12) })
        }
        if (actions.isNotEmpty()) {
            val bar = LinearLayout(this).apply { gravity = Gravity.END }
            actions.forEachIndexed { i, a ->
                bar.addView(btn(a.label, i == actions.size - 1) { d.dismiss(); a.fn() },
                    LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(8) })
            }
            box.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(18) })
        }
        d.setContentView(box)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.88).toInt(), WRAP_CONTENT)
        d.show()
        return d
    }

    private fun say(m: String) { notice = m; noticeUntil = SystemClock.elapsedRealtime() + 6000; render() }

    // ---- lifecycle --------------------------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27 && BleService.inst?.callState == 2) { setShowWhenLocked(true); setTurnScreenOn(true) }
        window.statusBarColor = BG
        window.navigationBarColor = BG
        who = txt(14f, GREEN).apply { setOnClickListener { askName() } }
        status = txt(12f, GREEN).apply { setPadding(dp(12), dp(5), dp(12), dp(5)) }
        keep = CheckBox(this).apply {
            text = "auto bluetooth"
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setTextColor(DIM)
            buttonTintList = ColorStateList.valueOf(GREEN)
            isChecked = Store.keepOn(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Store.setKeepOn(this@MainActivity, on) }
        }
        empty = txt(13f, DIM).apply {
            text = "no messages yet.\npick someone in the to: button and say hi."
            gravity = Gravity.CENTER
            setPadding(0, dp(48), 0, 0)
        }
        chat = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(empty, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }
        scroll = ScrollView(this).apply {
            addView(chat)
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        toBtn = btn("") { pickTarget() }.apply {
            setSingleLine()
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
        }
        callBtn = btn("call") { callOrHangUp() }
        input = EditText(this).apply {
            hint = "type a message..."
            setHintTextColor(DIM)
            setTextColor(TEXT)
            typeface = Typeface.MONOSPACE
            textSize = 15f
            background = null
            if (Build.VERSION.SDK_INT >= 29) textCursorDrawable = DashCursor(dp(10), dp(2))
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, _, _ -> send(); true }
        }
        micBtn = btn("mic") {}
        micBtn.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { v.isPressed = true; startRec() }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.isPressed = false; stopRec() }
            }
            true
        }
        dash = txt(22f, GREEN).apply { text = "-"; setTypeface(Typeface.MONOSPACE, Typeface.BOLD) }
        val brand = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(txt(22f, GREEN).apply { text = "codLINK"; setTypeface(Typeface.MONOSPACE, Typeface.BOLD); letterSpacing = 0.04f })
            addView(dash)
        }
        val me = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(who, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(keep)
        }
        val sel = LinearLayout(this).apply {
            addView(toBtn, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(callBtn, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(8) })
        }
        val composer = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = shape(PANEL, 26)
            setPadding(dp(16), dp(6), dp(6), dp(6))
            addView(txt(16f, GREEN).apply { text = "› " })
            addView(input, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(micBtn, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { rightMargin = dp(6) })
            addView(btn("send", true) { send() })
        }
        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(18), dp(22), dp(18), dp(12))
            addView(brand)
            addView(txt(10f, DIM).apply { text = "// bluetooth only. no internet. no servers." })
            addView(me, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(10) })
            addView(status, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(6) })
            addView(scroll, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f).apply { topMargin = dp(6); bottomMargin = dp(8) })
            addView(sel, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(8) })
            addView(composer)
        }
        setContentView(FrameLayout(this).apply { addView(main); addView(buildCallUi()) })
        handleIntent(intent)
        if (Store.hasName(this)) askPermissions() else askName(true)
    }

    override fun onStart() {
        super.onStart()
        BleService.uiVisible = true
        BleService.onUpdate = { render() }
        BleService.inst?.rescan()
        go()
        ui.postDelayed({ checkBluetooth() }, 2500)
        ui.post(ticker)
        ui.post(blink)
        ui.post(callTick)
    }

    override fun onStop() {
        super.onStop()
        BleService.uiVisible = false
        BleService.onUpdate = null
        BleService.inst?.rescan()
        ui.removeCallbacksAndMessages(null)
        rec?.let { try { it.stop() } catch (e: RuntimeException) { }; it.release() }
        rec = null
        player?.release()
        player = null
    }

    // ---- name -------------------------------------------------------------------------------

    private fun askName(first: Boolean = false) {
        val et = EditText(this).apply {
            setText(Store.name(this@MainActivity))
            setSelection(text.length)
            setSingleLine()
            filters = arrayOf<InputFilter>(InputFilter.LengthFilter(12))
            setTextColor(GREEN)
            typeface = Typeface.MONOSPACE
            background = frame()
            if (Build.VERSION.SDK_INT >= 29) textCursorDrawable = DashCursor(dp(10), dp(2))
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(txt(12f, DIM).apply { text = "Other phones will see this name on your messages." })
            addView(et, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) })
        }
        dlg("your name", body, Act("save") {
            Store.setName(this, et.text.toString())
            BleService.inst?.readvertise()
            render()
            if (first) askPermissions()
        }).setCancelable(false)
    }

    // ---- permissions and service ------------------------------------------------------------

    private fun perms(): Array<String> {
        val l = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            l.add(Manifest.permission.BLUETOOTH_SCAN)
            l.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            l.add(Manifest.permission.BLUETOOTH_CONNECT)
        } else if (Build.VERSION.SDK_INT >= 23) {
            l.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= 23) l.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l.toTypedArray()
    }

    private fun btGranted() = Build.VERSION.SDK_INT < 23 ||
        perms().filter { it != Manifest.permission.POST_NOTIFICATIONS && it != Manifest.permission.RECORD_AUDIO }
            .all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun askPermissions() {
        if (Build.VERSION.SDK_INT >= 23 && perms().any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED })
            requestPermissions(perms(), 1)
        else go()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        if (requestCode == 2) { // microphone
            val ok = grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
            if (pendingAnswer) {
                pendingAnswer = false
                BleService.inst?.answer()
                if (!ok) say("Microphone is off, so they won't hear you. Allow it in Settings.")
            } else if (pendingCall) {
                pendingCall = false
                if (ok) callOrHangUp() else say("Microphone is off. Allow it in Settings to place calls.")
            } else {
                say(if (ok) "Microphone allowed. Hold the mic button to talk." else "Microphone is off. Allow it in Settings to send voice.")
            }
            return
        }
        if (btGranted()) go()
        else status.text = "Bluetooth permission is off. Allow it in Settings, then reopen the app."
    }

    private fun go() {
        if (!btGranted()) return
        val i = Intent(this, BleService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        askBattery()
    }

    private fun askBattery() {
        if (Build.VERSION.SDK_INT < 23) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val prefs = getSharedPreferences("chat", MODE_PRIVATE)
        if (pm.isIgnoringBatteryOptimizations(packageName) || prefs.getBoolean("askedBattery", false)) return
        prefs.edit().putBoolean("askedBattery", true).apply()
        dlg("run in background",
            txt(13f, GREEN).apply { text = "Android may stop codLINK in the background. On the next screen, tap Allow to get messages when the app is closed." },
            Act("not now") {},
            Act("continue") {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            })
    }

    /** If Bluetooth is still off (the app couldn't switch it on silently), show Android's one-tap "turn on" prompt. */
    private fun checkBluetooth() {
        if (!BleService.uiVisible || !btGranted() || !Store.keepOn(this)) return
        val a = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (a != null && !a.isEnabled) startActivityForResult(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), 3)
    }

    // ---- sending ----------------------------------------------------------------------------

    private fun pickTarget() {
        Store.load(this)
        val near = BleService.inst?.nearby()?.map { it.id }?.toSet() ?: emptySet()
        val ids = Store.known.keys.sortedByDescending { it in near }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        lateinit var d: Dialog
        fun row(label: String, key: String?, name: String) {
            list.addView(txt(15f, GREEN).apply {
                text = label
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { toKey = key; toLabel = name; d.dismiss(); render() }
            })
        }
        row("* Everyone nearby", null, "Everyone nearby")
        ids.forEach { row((if (it in near) "● " else "○ ") + Store.known[it], it, Store.known[it] ?: "?") }
        d = dlg("send to  (● here, ○ out of range)", ScrollView(this).apply { addView(list) })
    }

    private fun send() {
        val text = input.text.toString().trim().take(300)
        if (text.isEmpty()) return
        val s = BleService.inst
        if (s == null) { say("Still starting. Try again in a moment."); return }
        val err = s.send(toKey, toLabel, text)
        if (err != null) say(err) else input.setText("")
    }

    // ---- voice: hold the mic button, release to send ----------------------------------------

    @Suppress("DEPRECATION")
    private fun startRec() {
        if (toKey == null) { say("Pick a person in the To: button first. Voice goes to one person."); return }
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
            return
        }
        try {
            rec = (if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()).apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.AMR_NB)
                setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
                setAudioSamplingRate(8000)
                setAudioEncodingBitRate(5900)
                setMaxDuration(10_000)
                setOutputFile(File(cacheDir, "rec.amr").path)
                prepare()
                start()
            }
            recStart = SystemClock.elapsedRealtime()
            micBtn.text = "● rec"
            micBtn.setTextColor(RED)
        } catch (e: Exception) {
            rec?.release()
            rec = null
            say("Couldn't start the microphone.")
        }
    }

    private fun stopRec() {
        val r = rec ?: return
        rec = null
        micBtn.text = "mic"
        micBtn.setTextColor(GREEN)
        val ms = SystemClock.elapsedRealtime() - recStart
        try { r.stop() } catch (e: RuntimeException) { }
        r.release()
        val key = toKey ?: return
        if (ms < 700) { say("Hold the mic button while you talk."); return }
        val s = BleService.inst
        if (s == null) { say("Still starting. Try again in a moment."); return }
        val bytes = File(cacheDir, "rec.amr").readBytes()
        if (bytes.size < 100) { say("Nothing was recorded. Try again."); return }
        s.sendVoice(key, toLabel, bytes)
    }

    private fun play(id: String) {
        val f = Store.voice(this, id)
        if (!f.exists()) { say("Voice file not found."); return }
        player?.release()
        player = try {
            MediaPlayer().apply {
                setDataSource(f.path)
                prepare()
                setOnCompletionListener { it.release(); if (player === it) player = null }
                start()
            }
        } catch (e: Exception) { say("Couldn't play it."); null }
    }

    // ---- screen -----------------------------------------------------------------------------

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
        render()
    }

    private fun callOrHangUp() {
        val s = BleService.inst
        if (s == null) { say("Still starting. Try again in a moment."); return }
        if (s.callState != 0) { s.hangUp(); return }
        val key = toKey
        if (key == null) { say("Pick a person in the To: button first."); return }
        if (!micGranted()) { pendingCall = true; requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2); return }
        val err = s.startCall(key, toLabel)
        if (err != null) say(err)
    }

    private fun micGranted() = Build.VERSION.SDK_INT < 23 ||
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun handleIntent(i: Intent?) {
        if (i?.action == "answer") { i.action = null; ui.postDelayed({ answerCall() }, 300) }
    }

    private fun answerCall() {
        val s = BleService.inst ?: return
        if (s.callState != 2) return
        if (!micGranted()) { pendingAnswer = true; requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2); return }
        s.answer()
    }

    private fun toggleMute() {
        val v = BleService.inst?.voice ?: return
        v.muted = !v.muted
        syncCallUi()
    }

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    /** Full-screen call overlay: who, state/timer, audio link status, level bars, output picker, controls. */
    private fun buildCallUi(): View {
        cAvatar = txt(44f, GREEN).apply { gravity = Gravity.CENTER; setTypeface(Typeface.MONOSPACE, Typeface.BOLD); background = shape(PANEL2, 60) }
        cName = txt(24f, TEXT).apply { gravity = Gravity.CENTER; setTypeface(Typeface.MONOSPACE, Typeface.BOLD) }
        cState = txt(14f, DIM).apply { gravity = Gravity.CENTER }
        cLink = txt(12f, GREEN).apply { setPadding(dp(12), dp(5), dp(12), dp(5)) }
        cLevels = txt(13f, GREEN)
        cInput = txt(11f, DIM)
        cRoutes = LinearLayout(this).apply { gravity = Gravity.CENTER }
        cMute = btn("mute") { toggleMute() }
        cEnd = btn("end call", true) { BleService.inst?.hangUp() }.apply { background = tap(RED, 22) }
        cAnswer = btn("answer", true) { answerCall() }
        cDecline = btn("decline") { BleService.inst?.hangUp() }.apply { setTextColor(BG); background = tap(RED, 22) }
        val ctl = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            for (b in listOf(cDecline, cAnswer, cMute, cEnd)) {
                addView(b, lp(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(6); rightMargin = dp(6) })
            }
        }
        callUi = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(BG)
            setPadding(dp(24), dp(40), dp(24), dp(28))
            isClickable = true // keeps touches from reaching the chat underneath
            addView(txt(11f, DIM).apply { text = "CALL  ·  codLINK-"; letterSpacing = 0.15f })
            addView(cAvatar, lp(dp(120), dp(120)).apply { topMargin = dp(36) })
            addView(cName, lp(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(20) })
            addView(cState, lp(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(4) })
            addView(cLink, lp(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(18) })
            addView(cLevels, lp(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(14) })
            addView(txt(11f, DIM).apply { text = "OUTPUT"; letterSpacing = 0.15f }, lp(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(26) })
            addView(cRoutes, lp(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) })
            addView(cInput, lp(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(10) })
            addView(View(this@MainActivity), lp(1, 0, 1f))
            addView(ctl, lp(MATCH_PARENT, WRAP_CONTENT))
            visibility = View.GONE
        }
        return callUi
    }

    /** Keeps the call screen, lock-screen behaviour, volume keys and screen-on flag in step with the call state. */
    private fun syncCallUi() {
        val s = BleService.inst
        val st = s?.callState ?: 0
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(st == 2 || st == 3); setTurnScreenOn(st == 2) }
        volumeControlStream = if (st == 3) AudioManager.STREAM_VOICE_CALL else AudioManager.USE_DEFAULT_STREAM_TYPE
        if (st == 3) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (s == null || st == 0) { callUi.visibility = View.GONE; callStart = 0L; lastRoute = ""; return }
        callUi.visibility = View.VISIBLE
        val now = SystemClock.elapsedRealtime()
        if (st == 3 && callStart == 0L) callStart = now
        cAvatar.text = s.callPeerName.take(1).uppercase()
        cName.text = s.callPeerName
        val dots = ".".repeat(1 + (now / 500 % 3).toInt())
        cState.text = when (st) {
            1 -> "calling$dots"
            2 -> "incoming call$dots"
            else -> { val sec = (now - callStart) / 1000; "%02d:%02d".format(sec / 60, sec % 60) }
        }
        val live = st == 3
        cAnswer.visibility = if (st == 2) View.VISIBLE else View.GONE
        cDecline.visibility = if (st == 2) View.VISIBLE else View.GONE
        cEnd.visibility = if (st == 2) View.GONE else View.VISIBLE
        for (v in listOf(cMute, cLevels, cRoutes, cInput, cLink)) v.visibility = if (live) View.VISIBLE else View.GONE
        if (!live) return
        val v = s.voice
        fun bars(n: Int) = "▮".repeat(n.coerceIn(0, 8)) + "▯".repeat(8 - n.coerceIn(0, 8))
        cLevels.text = "you   ${bars(v?.micLevel ?: 0)}\nthem  ${bars(v?.hearLevel ?: 0)}"
        val problem = when {
            !micGranted() -> "microphone is off. Allow it in Settings"
            v != null && v.error.isNotEmpty() -> v.error
            else -> ""
        }
        val (linkText, bad) = when {
            problem.isNotEmpty() -> "[!] $problem" to true
            s.linkInfo == "ready" -> "[+] audio link ready" to false
            s.linkInfo.startsWith("connecting") -> "[*] connecting audio..." to false
            else -> "[!] audio: ${s.linkInfo}" to true
        }
        cLink.text = linkText
        cLink.setTextColor(if (bad) RED else GREEN)
        cLink.background = shape(if (bad) 0xFF2A1010.toInt() else PANEL2, 14)
        val muted = v?.muted == true
        cMute.text = if (muted) "unmute" else "mute"
        cMute.setTextColor(if (muted) BG else GREEN)
        cMute.background = tap(if (muted) RED else PANEL2, 22)
        cInput.text = "INPUT  " + (if (s.routeKind == "headset") "headset mic" else "phone mic") + "  (auto)"
        val head = v?.hasHeadset() == true
        val key = s.routeKind + head
        if (key != lastRoute) {
            lastRoute = key
            cRoutes.removeAllViews()
            for (k in listOf("earpiece", "speaker") + (if (head) listOf("headset") else emptyList())) {
                cRoutes.addView(btn(k, k == s.routeKind) { s.setRoute(k); lastRoute = ""; syncCallUi() },
                    lp(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(4); rightMargin = dp(4) })
            }
        }
    }

    private fun locationOff(): Boolean {
        if (Build.VERSION.SDK_INT !in 23..30) return false // only Android 6 to 11 need Location for BLE scans
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return !lm.isProviderEnabled(LocationManager.GPS_PROVIDER) && !lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    }

    private val clock = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())

    private fun render() {
        Store.load(this)
        val s = BleService.inst
        val n = s?.nearby()?.size ?: 0
        who.text = "@${Store.name(this)}  ✎"
        val (msg, color) = when {
            SystemClock.elapsedRealtime() < noticeUntil -> "[!] $notice" to RED
            locationOff() -> "[!] Turn on Location. Android 6 to 11 needs it to find nearby Bluetooth devices." to RED
            s == null -> "[*] starting..." to DIM
            s.warning.isNotEmpty() -> "[!] ${s.warning}" to RED
            s.callState == 1 -> "[*] calling ${s.callPeerName}..." to GREEN
            s.callState == 2 -> "[!] ${s.callPeerName} is calling..." to GREEN
            s.callState == 3 -> "[+] in call with ${s.callPeerName}" to GREEN
            n == 0 -> "[*] scanning for nearby phones..." to DIM
            else -> "[+] $n ${if (n == 1) "phone" else "phones"} nearby" to GREEN
        }
        status.text = msg
        status.setTextColor(color)
        status.background = shape(if (color == RED) 0xFF2A1010.toInt() else PANEL2, 14)
        val inCall = s != null && s.callState != 0
        callBtn.text = if (inCall) "hang up" else "call"
        callBtn.setTextColor(if (inCall) BG else GREEN)
        callBtn.background = tap(if (inCall) RED else PANEL2, 22)
        if (s != null && s.callState == 3 && toKey != s.callPeerId) { toKey = s.callPeerId; toLabel = s.callPeerName }
        syncCallUi()
        toBtn.text = "→ $toLabel  ▾"
        drawChat()
    }

    /** Appends only the new lines; rebuilds (last 1000) on first draw or if the saved log was trimmed. */
    private fun drawChat() {
        val total = Store.total
        if (total == drawn) return
        val fresh = total - drawn
        val follow = drawn == 0 || !scroll.canScrollVertically(1)
        if (drawn == 0 || fresh < 0 || fresh > Store.lines.size) {
            chat.removeAllViews()
            chat.addView(empty, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            Store.lines.takeLast(1000).forEach { chat.addView(rowFor(it)) }
        } else {
            Store.lines.takeLast(fresh).forEach { chat.addView(rowFor(it)) }
        }
        drawn = total
        empty.visibility = if (Store.lines.isEmpty()) View.VISIBLE else View.GONE
        if (follow) scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    /** One saved line -> a bubble (yours right, theirs left) or a small centred system note. */
    private fun rowFor(raw: String): View {
        var l = raw
        var time = ""
        if (l.length > 14 && l[13] == '|' && l.substring(0, 13).all { it.isDigit() }) {
            time = clock.format(java.util.Date(l.substring(0, 13).toLong()))
            l = l.substring(14)
        }
        val vi = l.indexOf('\u0002') // voice lines end with \u0002<id>
        val vid = if (vi >= 0) l.substring(vi + 1) else ""
        if (vi >= 0) l = l.substring(0, vi)
        val wide = (resources.displayMetrics.widthPixels * 0.78).toInt()

        if (l.startsWith("✓") || l.startsWith("✗") || l.startsWith("⏳") || l.startsWith("📞")) {
            return txt(11f, if (l.startsWith("✗")) RED else DIM).apply {
                text = l
                gravity = Gravity.CENTER
                maxWidth = wide
                layoutParams = LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(8) }
            }
        }
        val mine = l.startsWith("Me → ")
        val head: String
        var body: String
        if (mine) {
            val rest = l.removePrefix("Me → ")
            head = "you → " + rest.substringBefore(": ")
            body = rest.substringAfter(": ", "")
        } else {
            head = l.substringBefore(": ")
            body = l.substringAfter(": ", "")
        }
        if (vid.isNotEmpty()) body = "▶  voice message"
        val r = dp(16).toFloat()
        val t = dp(4).toFloat()
        val bubble = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(9), dp(14), dp(10))
            background = GradientDrawable().apply {
                setColor(if (mine) PANEL2 else PANEL)
                cornerRadii = if (mine) floatArrayOf(r, r, r, r, t, t, r, r) else floatArrayOf(r, r, r, r, r, r, t, t)
            }
            if (vid.isNotEmpty()) setOnClickListener { play(vid) }
        }
        bubble.addView(txt(10f, if (mine) DIM else GREEN).apply {
            text = head + (if (time.isNotEmpty()) "  ·  $time" else "")
            if (!mine) setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
        })
        bubble.addView(txt(15f, TEXT).apply { text = body; maxWidth = wide; setLineSpacing(0f, 1.15f) },
            LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(3) })
        return LinearLayout(this).apply {
            gravity = if (mine) Gravity.END else Gravity.START
            addView(bubble)
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(6) }
        }
    }
}
