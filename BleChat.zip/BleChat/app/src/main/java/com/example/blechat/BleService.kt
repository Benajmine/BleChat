package com.example.blechat

import android.annotation.SuppressLint
import android.app.*
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.Ringtone
import android.media.RingtoneManager
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID

private val SERVICE: UUID = UUID.fromString("7b1f0001-0c3a-4e57-9f6d-2a5e8c1d4b90")
private val INBOX: UUID = UUID.fromString("7b1f0002-0c3a-4e57-9f6d-2a5e8c1d4b90")
private const val CHUNK = 19                 // 20-byte BLE payload minus 1 flag byte
private const val FRESH_MS = 20_000L         // a phone counts as "in range" if heard within this time
private const val DAY_MS = 86_400_000L       // queued messages expire after 24 hours
private const val HOPS = 6                   // max relay hops for private messages
private const val NO_ADV = "This phone can't be discovered, so it can send but not receive."
private const val BT_OFF = "Bluetooth is off. Turn it on and this will resume."

/** A message on the wire. kind: A = to everyone in range, D = private (stored + relayed), R = delivery receipt (text = id of delivered message). */
class Env(val kind: Char, val id: String, val from: String, val fromName: String, val to: String,
          var ttl: Int, val ts: Long, val text: String) {
    val sentTo = HashSet<String>()   // phone ids we already handed this to
    fun wire() = "$kind|$id|$from|$to|$ttl|$ts|" + fromName.replace('|', '/').replace('\n', ' ') + "\n" + text

    companion object {
        fun parse(raw: String): Env? {
            val h = raw.substringBefore('\n').split('|')
            if (h.size < 7 || h[0].isEmpty()) return null
            return Env(h[0][0], h[1], h[2], h[6], h[3], h[4].toIntOrNull() ?: 0, h[5].toLongOrNull() ?: 0L, raw.substringAfter('\n', ""))
        }
    }
}

/** Everything saved on the phone: name, id, chat log, queued messages, known users, seen message ids. */
object Store {
    val lines = ArrayList<String>()
    val queue = ArrayList<Env>()
    val known = LinkedHashMap<String, String>() // phone id -> name
    private val seen = LinkedHashSet<String>()
    var version = 0
    var total = 0 // lines ever added, so the screen only appends new ones
    private var loaded = false
    private fun p(c: Context) = c.getSharedPreferences("chat", Context.MODE_PRIVATE)
    private fun split(s: String?) = (s ?: "").split('\u0001').filter { it.isNotEmpty() }

    fun load(c: Context) {
        if (loaded) return
        loaded = true
        val f = File(c.filesDir, "history.txt")
        if (!f.exists()) { // carry over the log saved by older versions
            val old = split(p(c).getString("log", ""))
            if (old.isNotEmpty()) f.writeText(old.joinToString("") { it.replace('\n', '\u0001') + "\n" })
            p(c).edit().remove("log").apply()
        }
        if (f.exists()) {
            val all = f.readLines().filter { it.isNotEmpty() }.map { it.replace('\u0001', '\n') }
            lines.addAll(all.takeLast(2000))
            if (all.size > 2000) f.writeText(lines.joinToString("") { it.replace('\n', '\u0001') + "\n" })
        }
        split(p(c).getString("queue", "")).mapNotNullTo(queue) { Env.parse(it) }
        split(p(c).getString("known", "")).forEach { val kv = it.split('\t'); if (kv.size == 2) known[kv[0]] = kv[1] }
        seen.addAll(split(p(c).getString("seen", "")))
        total = lines.size
    }

    fun add(c: Context, s: String) {
        load(c)
        val line = System.currentTimeMillis().toString() + "|" + s
        lines.add(line)
        total++
        if (lines.size > 2000) lines.removeAt(0)
        version++
        File(c.filesDir, "history.txt").appendText(line.replace('\n', '\u0001') + "\n")
    }

    fun saveQueue(c: Context) { p(c).edit().putString("queue", queue.joinToString("\u0001") { it.wire() }).apply() }

    fun learn(c: Context, pid: String, name: String) {
        if (pid.isEmpty() || name.isEmpty() || pid == id(c) || known[pid] == name) return
        load(c)
        known[pid] = name
        while (known.size > 50) known.remove(known.keys.first())
        p(c).edit().putString("known", known.entries.joinToString("\u0001") { it.key + "\t" + it.value }).apply()
        version++
    }

    /** False if we've already handled this message id. */
    fun markSeen(c: Context, mid: String): Boolean {
        load(c)
        if (!seen.add(mid)) return false
        while (seen.size > 300) seen.remove(seen.first())
        p(c).edit().putString("seen", seen.joinToString("\u0001")).apply()
        return true
    }

    fun hasName(c: Context) = p(c).contains("name")
    fun voice(c: Context, id: String) = File(c.filesDir, "v_$id.amr")
    fun keepOn(c: Context) = p(c).getBoolean("keepOn", true)
    fun setKeepOn(c: Context, on: Boolean) { p(c).edit().putBoolean("keepOn", on).apply() }

    fun name(c: Context): String {
        val n = p(c).getString("name", null)
        return if (n.isNullOrBlank()) Build.MODEL.take(12) else n
    }

    fun setName(c: Context, n: String) {
        p(c).edit().putString("name", n.trim().replace('\n', ' ').replace('|', '/').take(12)).apply()
    }

    fun id(c: Context): String {
        var i = p(c).getString("id", null)
        if (i == null) {
            i = "%04x".format(kotlin.random.Random.nextInt(0x10000))
            p(c).edit().putString("id", i).apply()
        }
        return i
    }
}

/**
 * Keeps BLE running (foreground service). Each phone advertises its id + name and hosts a write-only inbox.
 * Private messages are queued and handed to every phone we meet (store-and-forward), so they hop through
 * other users and are delivered when the destination is reached. Writes use 19-byte chunks (byte 0: 0 = more, 1 = last).
 */
@SuppressLint("MissingPermission")
class BleService : Service() {
    companion object {
        var inst: BleService? = null
        var uiVisible = false
        var onUpdate: (() -> Unit)? = null
    }

    class Peer(val dev: BluetoothDevice) {
        var id = ""
        var name = ""
        var seen = 0L
        fun key(): String = id.ifEmpty { dev.address }
        fun label(): String = name.ifEmpty { Store.known[id] ?: ("Phone " + dev.address.takeLast(5)) }
    }

    var warning = ""
    private val main = Handler(Looper.getMainLooper())
    private var adapter: BluetoothAdapter? = null
    private var server: BluetoothGattServer? = null
    private var scanning = false
    private var notifId = 100
    private val peers = HashMap<String, Peer>()
    private val partial = HashMap<String, ByteArrayOutputStream>()
    private val lastTry = HashMap<String, Long>()
    private val busy = HashSet<String>()
    private val piFlags = PendingIntent.FLAG_UPDATE_CURRENT or
        (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        inst = this
        Store.load(this)
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("run", "Background connection", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel("msg", "Messages", NotificationManager.IMPORTANCE_HIGH))
            nm.createNotificationChannel(NotificationChannel("call", "Calls", NotificationManager.IMPORTANCE_HIGH).apply { setSound(null, null); enableVibration(false) })
        }
        registerReceiver(btState, IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED))
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        when (i?.action) {
            "answer" -> { answer(); return START_STICKY }
            "decline", "hangup" -> { hangUp(); return START_STICKY }
        }
        if (i?.action == "stop" || !permsOk()) { stopForeground(true); stopSelf(); return START_NOT_STICKY }
        startForeground(1, ongoing())
        initBle()
        return START_STICKY
    }

    override fun onDestroy() {
        unregisterReceiver(btState)
        stopRinging()
        teardown()
        inst = null
        changed()
        super.onDestroy()
    }

    private fun permsOk() = Build.VERSION.SDK_INT < 31 || listOf(
        android.Manifest.permission.BLUETOOTH_SCAN,
        android.Manifest.permission.BLUETOOTH_ADVERTISE,
        android.Manifest.permission.BLUETOOTH_CONNECT
    ).all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun changed() { main.post { onUpdate?.invoke() } }

    private val btState = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1)) {
                BluetoothAdapter.STATE_ON -> { notifier().cancel(2); initBle() }
                BluetoothAdapter.STATE_OFF -> main.postDelayed({ ensureOn() }, 1500)
                BluetoothAdapter.STATE_TURNING_OFF -> { teardown(); warning = BT_OFF; changed() }
            }
        }
    }

    private fun initBle() {
        if (server != null) return
        val mgr = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        adapter = mgr.adapter
        if (adapter?.isEnabled != true) { warning = BT_OFF; changed(); ensureOn(); return }
        warning = ""
        server = mgr.openGattServer(this, serverCb)
        val svc = BluetoothGattService(SERVICE, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        svc.addCharacteristic(BluetoothGattCharacteristic(
            INBOX, BluetoothGattCharacteristic.PROPERTY_WRITE, BluetoothGattCharacteristic.PERMISSION_WRITE))
        server?.addService(svc)
        rescan()
        changed()
    }

    private fun teardown() {
        if (scanning) { adapter?.bluetoothLeScanner?.stopScan(scanCb); scanning = false }
        adapter?.bluetoothLeAdvertiser?.stopAdvertising(advCb)
        server?.close()
        server = null
        peers.clear()
        busy.clear()
    }

    /** Always scanning so relays and late deliveries work: fast and open while the app is on screen, slow and filtered in the background. */
    fun rescan() {
        val s = adapter?.bluetoothLeScanner ?: return
        if (scanning) { s.stopScan(scanCb); scanning = false }
        if (server == null) return
        val fg = uiVisible
        s.startScan(
            if (fg) null else listOf(ScanFilter.Builder().setServiceUuid(ParcelUuid(SERVICE)).build()),
            ScanSettings.Builder().setScanMode(if (fg) ScanSettings.SCAN_MODE_LOW_LATENCY else ScanSettings.SCAN_MODE_LOW_POWER).build(),
            scanCb)
        scanning = true
    }

    fun readvertise() { if (server != null) advertise() }

    private fun advertise() {
        val adv = adapter?.bluetoothLeAdvertiser
        if (adv == null) { warning = NO_ADV; changed(); return }
        adv.stopAdvertising(advCb)
        adv.startAdvertising(
            AdvertiseSettings.Builder().setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_BALANCED)
                .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH).setConnectable(true).build(),
            AdvertiseData.Builder().setIncludeDeviceName(false).addServiceUuid(ParcelUuid(SERVICE))
                .addManufacturerData(0xFFFF, Store.id(this).toByteArray()).build(),
            AdvertiseData.Builder().setIncludeDeviceName(false)
                .addManufacturerData(0xFFFE, Store.name(this).toByteArray().take(24).toByteArray()).build(),
            advCb)
    }

    private val advCb = object : AdvertiseCallback() {
        override fun onStartFailure(code: Int) { main.post { warning = "$NO_ADV (code $code)"; changed() } }
        override fun onStartSuccess(s: AdvertiseSettings?) {
            main.post { if (warning.startsWith(NO_ADV)) { warning = ""; changed() } }
        }
    }

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(type: Int, r: ScanResult) {
            val rec = r.scanRecord ?: return
            val addr = r.device.address
            val idb = rec.getManufacturerSpecificData(0xFFFF)
            val nb = rec.getManufacturerSpecificData(0xFFFE)
            val ours = rec.serviceUuids?.contains(ParcelUuid(SERVICE)) == true || (peers.containsKey(addr) && nb != null)
            if (!ours) return
            val isNew = !peers.containsKey(addr)
            val p = peers.getOrPut(addr) { Peer(r.device) }
            val before = p.id + p.name
            p.seen = SystemClock.elapsedRealtime()
            if (idb != null && idb.size == 4) p.id = String(idb, Charsets.UTF_8)
            if (nb != null) p.name = String(nb, Charsets.UTF_8)
            if (p.id.isNotEmpty()) {
                if (p.name.isEmpty()) p.name = Store.known[p.id] ?: ""
                Store.learn(this@BleService, p.id, p.name)
                sync(p)
            }
            if (isNew || before != p.id + p.name) changed()
        }
        override fun onScanFailed(code: Int) { warning = "Scan failed (code $code). Turn Bluetooth off and on."; changed() }
    }

    private val serverCb = object : BluetoothGattServerCallback() {
        override fun onServiceAdded(s: Int, svc: BluetoothGattService?) { main.post { advertise() } }

        override fun onCharacteristicWriteRequest(
            d: BluetoothDevice, id: Int, c: BluetoothGattCharacteristic,
            prepared: Boolean, needsResponse: Boolean, offset: Int, v: ByteArray
        ) {
            if (needsResponse) server?.sendResponse(d, id, BluetoothGatt.GATT_SUCCESS, offset, v)
            if (v.isEmpty()) return
            main.post {
                val buf = partial.getOrPut(d.address) { ByteArrayOutputStream() }
                buf.write(v, 1, v.size - 1)
                if (v[0].toInt() == 1) { partial.remove(d.address); received(buf.toString("UTF-8")) }
            }
        }
    }

    private fun addLine(s: String) { Store.add(this, s); changed() }

    // ---- receiving, relaying ----------------------------------------------------------------

    private fun received(raw: String) {
        val e = Env.parse(raw) ?: return
        val me = Store.id(this)
        Store.learn(this, e.from, e.fromName)
        if (!Store.markSeen(this, e.id)) return
        when (e.kind) {
            'A' -> { addLine(e.fromName + ": " + e.text); if (!uiVisible) notifyMsg(e.fromName, e.text, false) }
            'D' -> if (e.to == me) {
                addLine(e.fromName + " (private): " + e.text)
                if (!uiVisible) notifyMsg(e.fromName, e.text, true)
                enqueue(Env('R', newId(), me, Store.name(this), e.from, HOPS, System.currentTimeMillis(), e.id))
            } else relay(e)
            'C' -> if (e.to == me && fresh(e)) {
                if (callState != 0) {
                    enqueue(Env('X', newId(), me, Store.name(this), e.from, 1, System.currentTimeMillis(), e.id)) // busy
                } else {
                    callState = 2
                    callId = e.id
                    callPeerId = e.from
                    callPeerName = e.fromName
                    startRinging()
                    callNotif()
                    main.postDelayed(callTimeout, 35_000)
                    changed()
                }
            }
            'K' -> if (e.to == me && callState == 1 && e.text == callId) {
                main.removeCallbacks(callTimeout)
                callState = 3
                addLine("📞 " + e.fromName + " answered. Hold the mic button to talk.")
                callNotif()
                changed()
            }
            'X' -> if (e.to == me && callState != 0 && e.text == callId) {
                val was = callState
                addLine(when (was) { 1 -> "📞 " + e.fromName + " declined"; 2 -> "📞 Missed call from " + e.fromName; else -> "📞 Call ended" })
                if (was == 2) post(4, android.R.drawable.stat_notify_missed_call, "Missed call", e.fromName + " called you")
                endCall(false)
            }
            'V' -> if (e.to == me) {
                try { Store.voice(this, e.id).writeBytes(Base64.decode(e.text, Base64.NO_WRAP)) } catch (x: Exception) { return }
                addLine(e.fromName + ": 🎤 voice message \u0002" + e.id)
                if (callState == 3 && e.from == callPeerId) playClip(Store.voice(this, e.id))
                if (!uiVisible) notifyMsg(e.fromName, "🎤 Voice message", true)
                enqueue(Env('R', newId(), me, Store.name(this), e.from, HOPS, System.currentTimeMillis(), e.id))
            }
            'R' -> {
                val mine = Store.queue.firstOrNull { it.id == e.text }
                Store.queue.removeAll { it.id == e.text } // delivered: stop carrying it
                Store.saveQueue(this)
                if (e.to == me) { if (mine != null && mine.from == me) addLine("✓ Delivered to " + e.fromName) } else relay(e)
            }
        }
    }

    private fun relay(e: Env) {
        e.ttl -= 1
        if (e.ttl > 0 && System.currentTimeMillis() - e.ts < DAY_MS) enqueue(e)
    }

    private fun enqueue(e: Env) {
        Store.queue.add(e)
        while (Store.queue.size > 60) Store.queue.removeAt(0)
        Store.saveQueue(this)
        syncAll(true)
    }

    private fun newId() = "%08x".format(kotlin.random.Random.nextInt())

    fun nearby(): List<Peer> {
        val now = SystemClock.elapsedRealtime()
        peers.values.removeAll { now - it.seen > 300_000 }
        return peers.values.filter { now - it.seen < FRESH_MS }
            .groupBy { it.key() }.values.map { g -> g.maxByOrNull { it.seen }!! }
            .sortedBy { it.label().lowercase() }
    }

    /** Hand every queued message this phone hasn't seen yet to [p] (the destination, or a relay). */
    private fun sync(p: Peer, force: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        if (p.id.isEmpty() || p.id in busy || (!force && now - (lastTry[p.id] ?: 0L) < 30_000)) return
        val todo = Store.queue.filter { p.id !in it.sentTo && it.from != p.id && (it.kind == 'D' || it.kind == 'R' || it.to == p.id) }
        if (todo.isEmpty()) return
        lastTry[p.id] = now
        busy.add(p.id)
        Sender(p, todo, false, 1)
    }

    private fun syncAll(force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (Store.queue.removeAll { now - it.ts > (if (it.kind == 'C' || it.kind == 'K' || it.kind == 'X') 60_000L else DAY_MS) }) Store.saveQueue(this)
        nearby().forEach { sync(it, force) }
    }

    /** toKey = null: everyone in range right now. Otherwise a phone id: queued and delivered whenever possible. */
    fun send(toKey: String?, toLabel: String, text: String): String? {
        val me = Store.id(this)
        val now = System.currentTimeMillis()
        if (toKey == null) {
            val targets = nearby()
            if (targets.isEmpty()) return "No one nearby yet. Open the app on the other phone and wait a few seconds."
            addLine("Me → everyone: $text")
            val e = Env('A', newId(), me, Store.name(this), "*", 1, now, text)
            targets.forEach { Sender(it, listOf(e), true, 1) }
            return null
        }
        Store.queue.add(Env('D', newId(), me, Store.name(this), toKey, HOPS, now, text))
        Store.saveQueue(this)
        addLine("Me → $toLabel: $text")
        if (nearby().none { it.id == toKey }) {
            addLine("⏳ $toLabel is out of range. Queued: it will hop through nearby phones or arrive when $toLabel is back in range.")
        }
        syncAll(true)
        return null
    }

    // ---- calls: ring a friend's phone ------------------------------------------------------
    // callState: 0 idle, 1 calling (ringing at the friend), 2 incoming (ringing here), 3 in call.
    // Signalling reuses the message pipe: C = ring, K = answer, X = decline / cancel / hang up (text = call id).
    // Once answered you talk with voice clips; clips from the other person auto-play during the call.
    var callState = 0
    var callId = ""
    var callPeerId = ""
    var callPeerName = ""
    private var ringtone: Ringtone? = null
    private var vibrator: Vibrator? = null

    private val ringLoop = object : Runnable {
        override fun run() {
            if (callState != 2) return
            if (ringtone?.isPlaying == false) ringtone?.play()
            main.postDelayed(this, 1500)
        }
    }

    private val callTimeout = object : Runnable {
        override fun run() {
            if (callState == 1) {
                addLine("📞 No answer from $callPeerName")
                endCall(true)
            } else if (callState == 2) {
                addLine("📞 Missed call from $callPeerName")
                post(4, android.R.drawable.stat_notify_missed_call, "Missed call", "$callPeerName called you")
                endCall(false)
            }
        }
    }

    private fun fresh(e: Env) = Math.abs(System.currentTimeMillis() - e.ts) < 120_000

    fun startCall(toKey: String, toLabel: String): String? {
        if (callState != 0) return "You're already in a call."
        if (nearby().none { it.id == toKey }) return "$toLabel is out of range. Calls only work while you're both in Bluetooth range."
        callState = 1
        callPeerId = toKey
        callPeerName = toLabel
        callId = newId()
        enqueue(Env('C', callId, Store.id(this), Store.name(this), toKey, 1, System.currentTimeMillis(), ""))
        main.postDelayed(callTimeout, 35_000)
        changed()
        return null
    }

    fun answer() {
        if (callState != 2) return
        stopRinging()
        main.removeCallbacks(callTimeout)
        callState = 3
        enqueue(Env('K', newId(), Store.id(this), Store.name(this), callPeerId, 1, System.currentTimeMillis(), callId))
        addLine("📞 In call with $callPeerName. Hold the mic button to talk.")
        callNotif()
        changed()
    }

    fun hangUp() {
        if (callState == 0) return
        addLine(when (callState) { 1 -> "📞 Call cancelled"; 2 -> "📞 Call declined"; else -> "📞 Call ended" })
        endCall(true)
    }

    private fun endCall(tellPeer: Boolean) {
        main.removeCallbacks(callTimeout)
        if (tellPeer && callState != 0) {
            enqueue(Env('X', newId(), Store.id(this), Store.name(this), callPeerId, 1, System.currentTimeMillis(), callId))
        }
        stopRinging()
        notifier().cancel(3)
        callState = 0
        callId = ""
        callPeerId = ""
        callPeerName = ""
        changed()
    }

    @Suppress("DEPRECATION")
    private fun startRinging() {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (am.ringerMode == AudioManager.RINGER_MODE_NORMAL) {
            ringtone = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE))
            ringtone?.play()
        }
        if (am.ringerMode != AudioManager.RINGER_MODE_SILENT) {
            vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            vibrator?.vibrate(longArrayOf(0, 800, 700), 0)
        }
        main.postDelayed(ringLoop, 1500)
    }

    private fun stopRinging() {
        main.removeCallbacks(ringLoop)
        ringtone?.stop()
        ringtone = null
        vibrator?.cancel()
        vibrator = null
    }

    private fun playClip(f: File) {
        try {
            MediaPlayer().apply {
                setDataSource(f.path)
                prepare()
                setOnCompletionListener { it.release() }
                start()
            }
        } catch (e: Exception) { }
    }

    /** Ringing notification (Answer / Decline, wakes the screen where Android allows) or in-call notification (Hang up). */
    private fun callNotif() {
        val act = { name: String, req: Int ->
            PendingIntent.getService(this, req, Intent(this, BleService::class.java).setAction(name), piFlags)
        }
        val b = builder("call").setSmallIcon(android.R.drawable.stat_sys_phone_call).setOngoing(true)
            .setCategory(Notification.CATEGORY_CALL).setContentIntent(openApp())
        if (callState == 2) {
            b.setContentTitle("Incoming call").setContentText("$callPeerName is calling")
                .setFullScreenIntent(openApp(), true)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Decline", act("decline", 4))
                .addAction(android.R.drawable.ic_menu_call, "Answer", act("answer", 5))
        } else {
            b.setContentTitle("In call with $callPeerName").setContentText("Open the app and hold the mic button to talk")
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Hang up", act("hangup", 6))
        }
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_HIGH)
        notifier().notify(3, b.build())
    }

    /** Voice clip (AMR audio) to one phone: queued like a private message, but only the destination receives it. */
    fun sendVoice(toKey: String, toLabel: String, amr: ByteArray) {
        val id = newId()
        Store.voice(this, id).writeBytes(amr)
        Store.queue.add(Env('V', id, Store.id(this), Store.name(this), toKey, 1, System.currentTimeMillis(), Base64.encodeToString(amr, Base64.NO_WRAP)))
        Store.saveQueue(this)
        addLine("Me → $toLabel: 🎤 voice message \u0002$id")
        if (nearby().none { it.id == toKey }) addLine("⏳ $toLabel is out of range. Voice message queued; it will go when $toLabel is back in range.")
        syncAll(true)
    }

    /** One connection: write each message in order, in chunks (byte 0: 0 = more, 1 = last). */
    private inner class Sender(val peer: Peer, val envs: List<Env>, val report: Boolean, val attempt: Int) :
        BluetoothGattCallback() {
        private var idx = 0
        private var pos = 0
        private var data = envs[0].wire().toByteArray()
        private var chr: BluetoothGattCharacteristic? = null
        private var per = CHUNK // payload bytes per write; grows if a bigger MTU is agreed
        private var discovering = false

        init {
            if (Build.VERSION.SDK_INT >= 23) peer.dev.connectGatt(this@BleService, false, this, BluetoothDevice.TRANSPORT_LE)
            else peer.dev.connectGatt(this@BleService, false, this)
        }

        override fun onConnectionStateChange(g: BluetoothGatt, st: Int, state: Int) {
            if (state == BluetoothProfile.STATE_CONNECTED) {
                if (g.requestMtu(247)) main.postDelayed({ discover(g) }, 1500) else discover(g)
            }
            else if (state == BluetoothProfile.STATE_DISCONNECTED) { g.close(); main.post { finished() } }
        }

        private fun discover(g: BluetoothGatt) {
            if (discovering) return
            discovering = true
            g.discoverServices()
        }

        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, st: Int) {
            if (st == BluetoothGatt.GATT_SUCCESS) per = maxOf(CHUNK, mtu - 4)
            discover(g)
        }

        override fun onServicesDiscovered(g: BluetoothGatt, st: Int) {
            chr = g.getService(SERVICE)?.getCharacteristic(INBOX)
            if (chr == null) g.disconnect() else write(g)
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, st: Int) {
            if (st != BluetoothGatt.GATT_SUCCESS) { g.disconnect(); return }
            if (pos >= data.size) {
                val e = envs[idx]
                main.post { handedOver(e) }
                idx++
                if (idx >= envs.size) { g.disconnect(); return }
                data = envs[idx].wire().toByteArray()
                pos = 0
            }
            write(g)
        }

        private fun write(g: BluetoothGatt) {
            val end = minOf(pos + per, data.size)
            val chunk = byteArrayOf((if (end == data.size) 1 else 0).toByte()) + data.copyOfRange(pos, end)
            pos = end
            val c = chr!!
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(c, chunk, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT)
            } else {
                c.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                c.value = chunk
                g.writeCharacteristic(c)
            }
        }

        private fun handedOver(e: Env) {
            e.sentTo.add(peer.id)
            if (e.kind == 'A') { if (report) addLine("✓ Delivered to " + peer.label()); return }
            if (e.to == peer.id) { // reached the destination itself
                Store.queue.remove(e)
                Store.saveQueue(this@BleService)
                if ((e.kind == 'D' || e.kind == 'V') && e.from == Store.id(this@BleService)) addLine("✓ Delivered to " + peer.label())
            }
        }

        private fun finished() {
            busy.remove(peer.id)
            if (idx >= envs.size) return
            if (idx == 0 && attempt < 3) { // first try failed: retry (some phones need a second go)
                busy.add(peer.id)
                main.postDelayed({ Sender(peer, envs, report, attempt + 1) }, 800)
            } else if (report) addLine("✗ Couldn't reach " + peer.label() + ". Move closer and try again.")
            // queued private messages stay queued and are retried when this phone is seen again
        }
    }

    // ---- notifications ----------------------------------------------------------------------

    private fun builder(channel: String): Notification.Builder =
        (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channel) else Notification.Builder(this))
            .setColor(0xFF00FF41.toInt())

    private fun openApp(): PendingIntent = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), piFlags)

    private fun ongoing(): Notification {
        val stop = PendingIntent.getService(this, 1, Intent(this, BleService::class.java).setAction("stop"), piFlags)
        return builder("run").setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("codLINK is on")
            .setContentText("Listening for messages from nearby phones")
            .setContentIntent(openApp()).setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop).build()
    }

    private fun notifier() = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun post(id: Int, icon: Int, title: String, text: String) {
        val b = builder("msg").setSmallIcon(icon).setContentTitle(title).setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(openApp()).setAutoCancel(true)
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL)
        notifier().notify(id, b.build())
    }

    private fun notifyMsg(name: String, text: String, priv: Boolean) =
        post(notifId++, android.R.drawable.stat_notify_chat, if (priv) "$name (private)" else name, text)

    /** Switches Bluetooth back on if it was turned off. Apps targeting Android 13+ aren't allowed to, so this app targets 12L. */
    @Suppress("DEPRECATION")
    private fun ensureOn() {
        val a = adapter ?: return
        if (a.isEnabled || !Store.keepOn(this) || !permsOk()) return
        val started = try { a.enable() } catch (e: SecurityException) { false }
        main.postDelayed({
            if (adapter?.isEnabled != true && Store.keepOn(this)) {
                post(2, android.R.drawable.stat_sys_data_bluetooth, "Bluetooth is off", "You won't receive messages. Tap to turn it on.")
            }
        }, if (started) 6000L else 0L)
    }
}
