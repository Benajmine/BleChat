package com.example.blechat

import android.annotation.SuppressLint
import android.app.*
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import java.io.ByteArrayOutputStream
import java.util.UUID

private val SERVICE: UUID = UUID.fromString("7b1f0001-0c3a-4e57-9f6d-2a5e8c1d4b90")
private val INBOX: UUID = UUID.fromString("7b1f0002-0c3a-4e57-9f6d-2a5e8c1d4b90")
private const val CHUNK = 19                 // 20-byte BLE payload minus 1 flag byte
private const val FRESH_MS = 20_000L         // a phone counts as "in range" if heard within this time
private const val DAY_MS = 86_400_000L       // queued messages expire after 24 hours
private const val HOPS = 6                   // max relay hops for private messages
private const val NO_ADV = "This phone can't be discovered, so it can send but not receive."
private const val BT_OFF = "Bluetooth is off. Turn it on and this will resume."

/** A message on the wire. kind: A = to everyone in range, D = private (stored + relayed), R = delivery receipt (text = id of delivered message). */
class Env(val kind: Char, val id: String, val from: String, val fromName: String, val to: String,
          var ttl: Int, val ts: Long, val text: String) {
    val sentTo = HashSet<String>()   // phone ids we already handed this to
    fun wire() = "$kind|$id|$from|$to|$ttl|$ts|" + fromName.replace('|', '/').replace('\n', ' ') + "\n" + text

    companion object {
        fun parse(raw: String): Env? {
            val h = raw.substringBefore('\n').split('|')
            if (h.size < 7 || h[0].isEmpty()) return null
            return Env(h[0][0], h[1], h[2], h[6], h[3], h[4].toIntOrNull() ?: 0, h[5].toLongOrNull() ?: 0L, raw.substringAfter('\n', ""))
        }
    }
}

/** Everything saved on the phone: name, id, chat log, queued messages, known users, seen message ids. */
object Store {
    val lines = ArrayList<String>()
    val queue = ArrayList<Env>()
    val known = LinkedHashMap<String, String>() // phone id -> name
    private val seen = LinkedHashSet<String>()
    var version = 0
    private var loaded = false
    private fun p(c: Context) = c.getSharedPreferences("chat", Context.MODE_PRIVATE)
    private fun split(s: String?) = (s ?: "").split('\u0001').filter { it.isNotEmpty() }

    fun load(c: Context) {
        if (loaded) return
        loaded = true
        lines.addAll(split(p(c).getString("log", "")))
        split(p(c).getString("queue", "")).mapNotNullTo(queue) { Env.parse(it) }
        split(p(c).getString("known", "")).forEach { val kv = it.split('\t'); if (kv.size == 2) known[kv[0]] = kv[1] }
        seen.addAll(split(p(c).getString("seen", "")))
    }

    fun add(c: Context, s: String) {
        load(c)
        lines.add(s)
        while (lines.size > 200) lines.removeAt(0)
        version++
        p(c).edit().putString("log", lines.joinToString("\u0001")).apply()
    }

    fun saveQueue(c: Context) { p(c).edit().putString("queue", queue.joinToString("\u0001") { it.wire() }).apply() }

    fun learn(c: Context, pid: String, name: String) {
        if (pid.isEmpty() || name.isEmpty() || pid == id(c) || known[pid] == name) return
        load(c)
        known[pid] = name
        while (known.size > 50) known.remove(known.keys.first())
        p(c).edit().putString("known", known.entries.joinToString("\u0001") { it.key + "\t" + it.value }).apply()
        version++
    }

    /** False if we've already handled this message id. */
    fun markSeen(c: Context, mid: String): Boolean {
        load(c)
        if (!seen.add(mid)) return false
        while (seen.size > 300) seen.remove(seen.first())
        p(c).edit().putString("seen", seen.joinToString("\u0001")).apply()
        return true
    }

    fun hasName(c: Context) = p(c).contains("name")
    fun keepOn(c: Context) = p(c).getBoolean("keepOn", true)
    fun setKeepOn(c: Context, on: Boolean) { p(c).edit().putBoolean("keepOn", on).apply() }

    fun name(c: Context): String {
        val n = p(c).getString("name", null)
        return if (n.isNullOrBlank()) Build.MODEL.take(12) else n
    }

    fun setName(c: Context, n: String) {
        p(c).edit().putString("name", n.trim().replace('\n', ' ').replace('|', '/').take(12)).apply()
    }

    fun id(c: Context): String {
        var i = p(c).getString("id", null)
        if (i == null) {
            i = "%04x".format(kotlin.random.Random.nextInt(0x10000))
            p(c).edit().putString("id", i).apply()
        }
        return i
    }
}

/**
 * Keeps BLE running (foreground service). Each phone advertises its id + name and hosts a write-only inbox.
 * Private messages are queued and handed to every phone we meet (store-and-forward), so they hop through
 * other users and are delivered when the destination is reached. Writes use 19-byte chunks (byte 0: 0 = more, 1 = last).
 */
@SuppressLint("MissingPermission")
class BleService : Service() {
    companion object {
        var inst: BleService? = null
        var uiVisible = false
        var onUpdate: (() -> Unit)? = null
    }

    class Peer(val dev: BluetoothDevice) {
        var id = ""
        var name = ""
        var seen = 0L
        fun key(): String = id.ifEmpty { dev.address }
        fun label(): String = name.ifEmpty { Store.known[id] ?: ("Phone " + dev.address.takeLast(5)) }
    }

    var warning = ""
    private val main = Handler(Looper.getMainLooper())
    private var adapter: BluetoothAdapter? = null
    private var server: BluetoothGattServer? = null
    private var scanning = false
    private var notifId = 100
    private val peers = HashMap<String, Peer>()
    private val partial = HashMap<String, ByteArrayOutputStream>()
    private val lastTry = HashMap<String, Long>()
    private val busy = HashSet<String>()
    private val piFlags = PendingIntent.FLAG_UPDATE_CURRENT or
        (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        inst = this
        Store.load(this)
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("run", "Background connection", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel("msg", "Messages", NotificationManager.IMPORTANCE_HIGH))
        }
        registerReceiver(btState, IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED))
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == "stop" || !permsOk()) { stopForeground(true); stopSelf(); return START_NOT_STICKY }
        startForeground(1, ongoing())
        initBle()
        return START_STICKY
    }

    override fun onDestroy() {
        unregisterReceiver(btState)
        teardown()
        inst = null
        changed()
        super.onDestroy()
    }

    private fun permsOk() = Build.VERSION.SDK_INT < 31 || listOf(
        android.Manifest.permission.BLUETOOTH_SCAN,
        android.Manifest.permission.BLUETOOTH_ADVERTISE,
        android.Manifest.permission.BLUETOOTH_CONNECT
    ).all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun changed() { main.post { onUpdate?.invoke() } }

    private val btState = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1)) {
                BluetoothAdapter.STATE_ON -> { notifier().cancel(2); initBle() }
                BluetoothAdapter.STATE_OFF -> main.postDelayed({ ensureOn() }, 1500)
                BluetoothAdapter.STATE_TURNING_OFF -> { teardown(); warning = BT_OFF; changed() }
            }
        }
    }

    private fun initBle() {
        if (server != null) return
        val mgr = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        adapter = mgr.adapter
        if (adapter?.isEnabled != true) { warning = BT_OFF; changed(); ensureOn(); return }
        warning = ""
        server = mgr.openGattServer(this, serverCb)
        val svc = BluetoothGattService(SERVICE, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        svc.addCharacteristic(BluetoothGattCharacteristic(
            INBOX, BluetoothGattCharacteristic.PROPERTY_WRITE, BluetoothGattCharacteristic.PERMISSION_WRITE))
        server?.addService(svc)
        rescan()
        changed()
    }

    private fun teardown() {
        if (scanning) { adapter?.bluetoothLeScanner?.stopScan(scanCb); scanning = false }
        adapter?.bluetoothLeAdvertiser?.stopAdvertising(advCb)
        server?.close()
        server = null
        peers.clear()
        busy.clear()
    }

    /** Always scanning so relays and late deliveries work: fast and open while the app is on screen, slow and filtered in the background. */
    fun rescan() {
        val s = adapter?.bluetoothLeScanner ?: return
        if (scanning) { s.stopScan(scanCb); scanning = false }
        if (server == null) return
        val fg = uiVisible
        s.startScan(
            if (fg) null else listOf(ScanFilter.Builder().setServiceUuid(ParcelUuid(SERVICE)).build()),
            ScanSettings.Builder().setScanMode(if (fg) ScanSettings.SCAN_MODE_LOW_LATENCY else ScanSettings.SCAN_MODE_LOW_POWER).build(),
            scanCb)
        scanning = true
    }

    fun readvertise() { if (server != null) advertise() }

    private fun advertise() {
        val adv = adapter?.bluetoothLeAdvertiser
        if (adv == null) { warning = NO_ADV; changed(); return }
        adv.stopAdvertising(advCb)
        adv.startAdvertising(
            AdvertiseSettings.Builder().setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_BALANCED)
                .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH).setConnectable(true).build(),
            AdvertiseData.Builder().setIncludeDeviceName(false).addServiceUuid(ParcelUuid(SERVICE))
                .addManufacturerData(0xFFFF, Store.id(this).toByteArray()).build(),
            AdvertiseData.Builder().setIncludeDeviceName(false)
                .addManufacturerData(0xFFFE, Store.name(this).toByteArray().take(24).toByteArray()).build(),
            advCb)
    }

    private val advCb = object : AdvertiseCallback() {
        override fun onStartFailure(code: Int) { main.post { warning = "$NO_ADV (code $code)"; changed() } }
        override fun onStartSuccess(s: AdvertiseSettings?) {
            main.post { if (warning.startsWith(NO_ADV)) { warning = ""; changed() } }
        }
    }

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(type: Int, r: ScanResult) {
            val rec = r.scanRecord ?: return
            val addr = r.device.address
            val idb = rec.getManufacturerSpecificData(0xFFFF)
            val nb = rec.getManufacturerSpecificData(0xFFFE)
            val ours = rec.serviceUuids?.contains(ParcelUuid(SERVICE)) == true || (peers.containsKey(addr) && nb != null)
            if (!ours) return
            val isNew = !peers.containsKey(addr)
            val p = peers.getOrPut(addr) { Peer(r.device) }
            val before = p.id + p.name
            p.seen = SystemClock.elapsedRealtime()
            if (idb != null && idb.size == 4) p.id = String(idb, Charsets.UTF_8)
            if (nb != null) p.name = String(nb, Charsets.UTF_8)
            if (p.id.isNotEmpty()) {
                if (p.name.isEmpty()) p.name = Store.known[p.id] ?: ""
                Store.learn(this@BleService, p.id, p.name)
                sync(p)
            }
            if (isNew || before != p.id + p.name) changed()
        }
        override fun onScanFailed(code: Int) { warning = "Scan failed (code $code). Turn Bluetooth off and on."; changed() }
    }

    private val serverCb = object : BluetoothGattServerCallback() {
        override fun onServiceAdded(s: Int, svc: BluetoothGattService?) { main.post { advertise() } }

        override fun onCharacteristicWriteRequest(
            d: BluetoothDevice, id: Int, c: BluetoothGattCharacteristic,
            prepared: Boolean, needsResponse: Boolean, offset: Int, v: ByteArray
        ) {
            if (needsResponse) server?.sendResponse(d, id, BluetoothGatt.GATT_SUCCESS, offset, v)
            if (v.isEmpty()) return
            main.post {
                val buf = partial.getOrPut(d.address) { ByteArrayOutputStream() }
                buf.write(v, 1, v.size - 1)
                if (v[0].toInt() == 1) { partial.remove(d.address); received(buf.toString("UTF-8")) }
            }
        }
    }

    private fun addLine(s: String) { Store.add(this, s); changed() }

    // ---- receiving, relaying ----------------------------------------------------------------

    private fun received(raw: String) {
        val e = Env.parse(raw) ?: return
        val me = Store.id(this)
        Store.learn(this, e.from, e.fromName)
        if (!Store.markSeen(this, e.id)) return
        when (e.kind) {
            'A' -> { addLine(e.fromName + ": " + e.text); if (!uiVisible) notifyMsg(e.fromName, e.text, false) }
            'D' -> if (e.to == me) {
                addLine(e.fromName + " (private): " + e.text)
                if (!uiVisible) notifyMsg(e.fromName, e.text, true)
                enqueue(Env('R', newId(), me, Store.name(this), e.from, HOPS, System.currentTimeMillis(), e.id))
            } else relay(e)
            'R' -> {
                val mine = Store.queue.firstOrNull { it.id == e.text }
                Store.queue.removeAll { it.id == e.text } // delivered: stop carrying it
                Store.saveQueue(this)
                if (e.to == me) { if (mine != null && mine.from == me) addLine("✓ Delivered to " + e.fromName) } else relay(e)
            }
        }
    }

    private fun relay(e: Env) {
        e.ttl -= 1
        if (e.ttl > 0 && System.currentTimeMillis() - e.ts < DAY_MS) enqueue(e)
    }

    private fun enqueue(e: Env) {
        Store.queue.add(e)
        while (Store.queue.size > 60) Store.queue.removeAt(0)
        Store.saveQueue(this)
        syncAll(true)
    }

    private fun newId() = "%08x".format(kotlin.random.Random.nextInt())

    fun nearby(): List<Peer> {
        val now = SystemClock.elapsedRealtime()
        peers.values.removeAll { now - it.seen > 300_000 }
        return peers.values.filter { now - it.seen < FRESH_MS }
            .groupBy { it.key() }.values.map { g -> g.maxByOrNull { it.seen }!! }
            .sortedBy { it.label().lowercase() }
    }

    /** Hand every queued message this phone hasn't seen yet to [p] (the destination, or a relay). */
    private fun sync(p: Peer, force: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        if (p.id.isEmpty() || p.id in busy || (!force && now - (lastTry[p.id] ?: 0L) < 30_000)) return
        val todo = Store.queue.filter { p.id !in it.sentTo && it.from != p.id }
        if (todo.isEmpty()) return
        lastTry[p.id] = now
        busy.add(p.id)
        Sender(p, todo, false, 1)
    }

    private fun syncAll(force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (Store.queue.removeAll { now - it.ts > DAY_MS }) Store.saveQueue(this)
        nearby().forEach { sync(it, force) }
    }

    /** toKey = null: everyone in range right now. Otherwise a phone id: queued and delivered whenever possible. */
    fun send(toKey: String?, toLabel: String, text: String): String? {
        val me = Store.id(this)
        val now = System.currentTimeMillis()
        if (toKey == null) {
            val targets = nearby()
            if (targets.isEmpty()) return "No one nearby yet. Open the app on the other phone and wait a few seconds."
            addLine("Me → everyone: $text")
            val e = Env('A', newId(), me, Store.name(this), "*", 1, now, text)
            targets.forEach { Sender(it, listOf(e), true, 1) }
            return null
        }
        Store.queue.add(Env('D', newId(), me, Store.name(this), toKey, HOPS, now, text))
        Store.saveQueue(this)
        addLine("Me → $toLabel: $text")
        if (nearby().none { it.id == toKey }) {
            addLine("⏳ $toLabel is out of range. Queued: it will hop through nearby phones or arrive when $toLabel is back in range.")
        }
        syncAll(true)
        return null
    }

    /** One connection: write each message in order, 19 bytes at a time. */
    private inner class Sender(val peer: Peer, val envs: List<Env>, val report: Boolean, val attempt: Int) :
        BluetoothGattCallback() {
        private var idx = 0
        private var pos = 0
        private var data = envs[0].wire().toByteArray()
        private var chr: BluetoothGattCharacteristic? = null

        init {
            if (Build.VERSION.SDK_INT >= 23) peer.dev.connectGatt(this@BleService, false, this, BluetoothDevice.TRANSPORT_LE)
            else peer.dev.connectGatt(this@BleService, false, this)
        }

        override fun onConnectionStateChange(g: BluetoothGatt, st: Int, state: Int) {
            if (state == BluetoothProfile.STATE_CONNECTED) g.discoverServices()
            else if (state == BluetoothProfile.STATE_DISCONNECTED) { g.close(); main.post { finished() } }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, st: Int) {
            chr = g.getService(SERVICE)?.getCharacteristic(INBOX)
            if (chr == null) g.disconnect() else write(g)
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, st: Int) {
            if (st != BluetoothGatt.GATT_SUCCESS) { g.disconnect(); return }
            if (pos >= data.size) {
                val e = envs[idx]
                main.post { handedOver(e) }
                idx++
                if (idx >= envs.size) { g.disconnect(); return }
                data = envs[idx].wire().toByteArray()
                pos = 0
            }
            write(g)
        }

        private fun write(g: BluetoothGatt) {
            val end = minOf(pos + CHUNK, data.size)
            val chunk = byteArrayOf((if (end == data.size) 1 else 0).toByte()) + data.copyOfRange(pos, end)
            pos = end
            val c = chr!!
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(c, chunk, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT)
            } else {
                c.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                c.value = chunk
                g.writeCharacteristic(c)
            }
        }

        private fun handedOver(e: Env) {
            e.sentTo.add(peer.id)
            if (e.kind == 'A') { if (report) addLine("✓ Delivered to " + peer.label()); return }
            if (e.to == peer.id) { // reached the destination itself
                Store.queue.remove(e)
                Store.saveQueue(this@BleService)
                if (e.kind == 'D' && e.from == Store.id(this@BleService)) addLine("✓ Delivered to " + peer.label())
            }
        }

        private fun finished() {
            busy.remove(peer.id)
            if (idx >= envs.size) return
            if (idx == 0 && attempt < 3) { // first try failed: retry (some phones need a second go)
                busy.add(peer.id)
                main.postDelayed({ Sender(peer, envs, report, attempt + 1) }, 800)
            } else if (report) addLine("✗ Couldn't reach " + peer.label() + ". Move closer and try again.")
            // queued private messages stay queued and are retried when this phone is seen again
        }
    }

    // ---- notifications ----------------------------------------------------------------------

    private fun builder(channel: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channel) else Notification.Builder(this)

    private fun openApp(): PendingIntent = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), piFlags)

    private fun ongoing(): Notification {
        val stop = PendingIntent.getService(this, 1, Intent(this, BleService::class.java).setAction("stop"), piFlags)
        return builder("run").setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("BLE Chat is on")
            .setContentText("Listening for messages from nearby phones")
            .setContentIntent(openApp()).setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop).build()
    }

    private fun notifier() = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun post(id: Int, icon: Int, title: String, text: String) {
        val b = builder("msg").setSmallIcon(icon).setContentTitle(title).setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(openApp()).setAutoCancel(true)
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL)
        notifier().notify(id, b.build())
    }

    private fun notifyMsg(name: String, text: String, priv: Boolean) =
        post(notifId++, android.R.drawable.stat_notify_chat, if (priv) "$name (private)" else name, text)

    /** Switches Bluetooth back on if it was turned off. Apps targeting Android 13+ aren't allowed to, so this app targets 12L. */
    @Suppress("DEPRECATION")
    private fun ensureOn() {
        val a = adapter ?: return
        if (a.isEnabled || !Store.keepOn(this) || !permsOk()) return
        val started = try { a.enable() } catch (e: SecurityException) { false }
        main.postDelayed({
            if (adapter?.isEnabled != true && Store.keepOn(this)) {
                post(2, android.R.drawable.stat_sys_data_bluetooth, "Bluetooth is off", "You won't receive messages. Tap to turn it on.")
            }
        }, if (started) 6000L else 0L)
    }
}
