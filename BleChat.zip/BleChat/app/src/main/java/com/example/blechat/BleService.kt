package com.example.blechat

import android.annotation.SuppressLint
import android.app.*
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import java.io.ByteArrayOutputStream
import java.util.UUID

private val SERVICE: UUID = UUID.fromString("7b1f0001-0c3a-4e57-9f6d-2a5e8c1d4b90")
private val INBOX: UUID = UUID.fromString("7b1f0002-0c3a-4e57-9f6d-2a5e8c1d4b90")
private val MAGIC = byteArrayOf(0x42, 0x43)  // "BC" marks our advertisement data
private const val CHUNK = 19                 // 20-byte BLE payload minus 1 flag byte
private const val FRESH_MS = 20_000L
private const val NO_ADV = "This phone can't be discovered, so it can send but not receive."
private const val BT_OFF = "Bluetooth is off. Turn it on and this will resume."

/** Name, id and chat history, saved on the phone. */
object Store {
    val lines = ArrayList<String>()
    var version = 0
    private var loaded = false
    private fun p(c: Context) = c.getSharedPreferences("chat", Context.MODE_PRIVATE)

    fun load(c: Context) {
        if (loaded) return
        loaded = true
        lines.addAll(p(c).getString("log", "")!!.split('\u0001').filter { it.isNotEmpty() })
    }

    fun add(c: Context, s: String) {
        load(c)
        lines.add(s)
        while (lines.size > 200) lines.removeAt(0)
        version++
        p(c).edit().putString("log", lines.joinToString("\u0001")).apply()
    }

    fun hasName(c: Context) = p(c).contains("name")

    fun name(c: Context): String {
        val n = p(c).getString("name", null)
        return if (n.isNullOrBlank()) Build.MODEL.take(12) else n
    }

    fun setName(c: Context, n: String) {
        p(c).edit().putString("name", n.trim().replace('\n', ' ').take(12)).apply()
    }

    fun id(c: Context): String {
        var i = p(c).getString("id", null)
        if (i == null) {
            i = "%04x".format(kotlin.random.Random.nextInt(0x10000))
            p(c).edit().putString("id", i).apply()
        }
        return i
    }
}

/**
 * Keeps BLE running (foreground service) so messages arrive and notify even when the app is closed.
 * Every phone advertises its name + the chat service and hosts a write-only inbox characteristic.
 * Sending = connect to a phone's inbox and write the text in 19-byte chunks (byte 0: 0 = more, 1 = last).
 */
@SuppressLint("MissingPermission")
class BleService : Service() {
    companion object {
        var inst: BleService? = null
        var uiVisible = false
        var onUpdate: (() -> Unit)? = null
    }

    class Peer(val dev: BluetoothDevice) {
        var id = ""
        var name = ""
        var seen = 0L
        fun key(): String = id.ifEmpty { dev.address }
        fun label(): String = name.ifEmpty { "Phone " + dev.address.takeLast(5) }
    }

    var warning = ""
    private val main = Handler(Looper.getMainLooper())
    private var adapter: BluetoothAdapter? = null
    private var server: BluetoothGattServer? = null
    private var scanning = false
    private var notifId = 100
    private val peers = HashMap<String, Peer>()
    private val partial = HashMap<String, ByteArrayOutputStream>()
    private val piFlags = PendingIntent.FLAG_UPDATE_CURRENT or
        (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        inst = this
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("run", "Background connection", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel("msg", "Messages", NotificationManager.IMPORTANCE_HIGH))
        }
        registerReceiver(btState, IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED))
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == "stop" || !permsOk()) { stopForeground(true); stopSelf(); return START_NOT_STICKY }
        startForeground(1, ongoing())
        initBle()
        return START_STICKY
    }

    override fun onDestroy() {
        unregisterReceiver(btState)
        teardown()
        inst = null
        changed()
        super.onDestroy()
    }

    private fun permsOk() = Build.VERSION.SDK_INT < 31 || listOf(
        android.Manifest.permission.BLUETOOTH_SCAN,
        android.Manifest.permission.BLUETOOTH_ADVERTISE,
        android.Manifest.permission.BLUETOOTH_CONNECT
    ).all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun changed() { main.post { onUpdate?.invoke() } }

    private val btState = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1)) {
                BluetoothAdapter.STATE_ON -> initBle()
                BluetoothAdapter.STATE_TURNING_OFF -> { teardown(); warning = BT_OFF; changed() }
            }
        }
    }

    private fun initBle() {
        if (server != null) return
        val mgr = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        adapter = mgr.adapter
        if (adapter?.isEnabled != true) { warning = BT_OFF; changed(); return }
        warning = ""
        server = mgr.openGattServer(this, serverCb)
        val svc = BluetoothGattService(SERVICE, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        svc.addCharacteristic(BluetoothGattCharacteristic(
            INBOX, BluetoothGattCharacteristic.PROPERTY_WRITE, BluetoothGattCharacteristic.PERMISSION_WRITE))
        server?.addService(svc)
        if (uiVisible) setScanning(true)
        changed()
    }

    private fun teardown() {
        setScanning(false)
        adapter?.bluetoothLeAdvertiser?.stopAdvertising(advCb)
        server?.close()
        server = null
        peers.clear()
    }

    /** Scanning only runs while the app is on screen, to save battery. */
    fun setScanning(on: Boolean) {
        if (on == scanning) return
        scanning = on
        val s = adapter?.bluetoothLeScanner
        if (s == null) { scanning = false; return }
        if (on) s.startScan(null, ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), scanCb)
        else s.stopScan(scanCb)
    }

    fun readvertise() { if (server != null) advertise() }

    private fun advertise() {
        val adv = adapter?.bluetoothLeAdvertiser
        if (adv == null) { warning = NO_ADV; changed(); return }
        val info = MAGIC + Store.id(this).toByteArray() + Store.name(this).toByteArray().take(21).toByteArray()
        adv.stopAdvertising(advCb)
        adv.startAdvertising(
            AdvertiseSettings.Builder()
                .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_BALANCED)
                .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
                .setConnectable(true).build(),
            AdvertiseData.Builder().setIncludeDeviceName(false).addServiceUuid(ParcelUuid(SERVICE)).build(),
            AdvertiseData.Builder().setIncludeDeviceName(false).addManufacturerData(0xFFFF, info).build(),
            advCb)
    }

    private val advCb = object : AdvertiseCallback() {
        override fun onStartFailure(code: Int) { main.post { warning = "$NO_ADV (code $code)"; changed() } }
        override fun onStartSuccess(s: AdvertiseSettings?) {
            main.post { if (warning.startsWith(NO_ADV)) { warning = ""; changed() } }
        }
    }

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(type: Int, r: ScanResult) {
            val rec = r.scanRecord ?: return
            val md = rec.getManufacturerSpecificData(0xFFFF)
            val mine = md != null && md.size >= 6 && md[0] == MAGIC[0] && md[1] == MAGIC[1]
            if (!mine && rec.serviceUuids?.contains(ParcelUuid(SERVICE)) != true) return
            val isNew = !peers.containsKey(r.device.address)
            val p = peers.getOrPut(r.device.address) { Peer(r.device) }
            val before = p.id + p.name
            p.seen = SystemClock.elapsedRealtime()
            if (mine) {
                p.id = String(md!!, 2, 4, Charsets.UTF_8)
                p.name = String(md, 6, md.size - 6, Charsets.UTF_8)
            }
            if (isNew || before != p.id + p.name) changed()
        }
        override fun onScanFailed(code: Int) { warning = "Scan failed (code $code). Turn Bluetooth off and on."; changed() }
    }

    private val serverCb = object : BluetoothGattServerCallback() {
        override fun onServiceAdded(s: Int, svc: BluetoothGattService?) { main.post { advertise() } }

        override fun onCharacteristicWriteRequest(
            d: BluetoothDevice, id: Int, c: BluetoothGattCharacteristic,
            prepared: Boolean, needsResponse: Boolean, offset: Int, v: ByteArray
        ) {
            if (needsResponse) server?.sendResponse(d, id, BluetoothGatt.GATT_SUCCESS, offset, v)
            if (v.isEmpty()) return
            main.post {
                val buf = partial.getOrPut(d.address) { ByteArrayOutputStream() }
                buf.write(v, 1, v.size - 1)
                if (v[0].toInt() == 1) { partial.remove(d.address); received(buf.toString("UTF-8")) }
            }
        }
    }

    private fun addLine(s: String) { Store.add(this, s); changed() }

    private fun received(raw: String) {
        if (raw.length < 2) return
        val priv = raw[0] == 'D'
        val name = raw.substring(1).substringBefore('\n')
        val text = raw.substringAfter('\n', "")
        addLine(name + (if (priv) " (private)" else "") + ": " + text)
        if (!uiVisible) notifyMsg(name, text, priv)
    }

    fun nearby(): List<Peer> {
        val now = SystemClock.elapsedRealtime()
        peers.values.removeAll { now - it.seen > 300_000 }
        return peers.values.filter { now - it.seen < FRESH_MS }
            .groupBy { it.key() }.values.map { g -> g.maxByOrNull { it.seen }!! }
            .sortedBy { it.label().lowercase() }
    }

    /** toKey = null sends to everyone nearby. Returns an error message, or null if sending started. */
    fun send(toKey: String?, toLabel: String, text: String): String? {
        val all = nearby()
        val targets = if (toKey == null) all else all.filter { it.key() == toKey }
        if (targets.isEmpty()) {
            return if (toKey == null) "No one nearby yet. Open the app on the other phone and wait a few seconds."
            else "$toLabel is out of range."
        }
        addLine("Me → " + (if (toKey == null) "everyone" else toLabel) + ": " + text)
        val data = ((if (toKey == null) "A" else "D") + Store.name(this) + "\n" + text).toByteArray()
        targets.forEach { Sender(it.dev, data, 1, it.label()) }
        return null
    }

    /** One short-lived connection per message per phone; retries up to 3 times (some phones fail the first try). */
    private inner class Sender(val dev: BluetoothDevice, val data: ByteArray, val attempt: Int, val label: String) :
        BluetoothGattCallback() {
        private var pos = 0
        private var ok = false
        private var chr: BluetoothGattCharacteristic? = null

        init {
            if (Build.VERSION.SDK_INT >= 23) dev.connectGatt(this@BleService, false, this, BluetoothDevice.TRANSPORT_LE)
            else dev.connectGatt(this@BleService, false, this)
        }

        override fun onConnectionStateChange(g: BluetoothGatt, st: Int, state: Int) {
            if (state == BluetoothProfile.STATE_CONNECTED) g.discoverServices()
            else if (state == BluetoothProfile.STATE_DISCONNECTED) { g.close(); main.post { done() } }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, st: Int) {
            chr = g.getService(SERVICE)?.getCharacteristic(INBOX)
            if (chr == null) g.disconnect() else write(g)
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, st: Int) {
            if (st != BluetoothGatt.GATT_SUCCESS) g.disconnect()
            else if (pos >= data.size) { ok = true; g.disconnect() }
            else write(g)
        }

        private fun write(g: BluetoothGatt) {
            val end = minOf(pos + CHUNK, data.size)
            val chunk = byteArrayOf((if (end == data.size) 1 else 0).toByte()) + data.copyOfRange(pos, end)
            pos = end
            val c = chr!!
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(c, chunk, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT)
            } else {
                c.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                c.value = chunk
                g.writeCharacteristic(c)
            }
        }

        private fun done() {
            when {
                ok -> addLine("✓ Delivered to $label")
                attempt < 3 -> main.postDelayed({ Sender(dev, data, attempt + 1, label) }, 800)
                else -> addLine("✗ Couldn't reach $label. Move closer and try again.")
            }
        }
    }

    private fun builder(channel: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channel) else Notification.Builder(this)

    private fun openApp(): PendingIntent = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), piFlags)

    private fun ongoing(): Notification {
        val stop = PendingIntent.getService(this, 1, Intent(this, BleService::class.java).setAction("stop"), piFlags)
        return builder("run").setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("BLE Chat is on")
            .setContentText("Listening for messages from nearby phones")
            .setContentIntent(openApp()).setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop).build()
    }

    private fun notifyMsg(name: String, text: String, priv: Boolean) {
        val b = builder("msg").setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(if (priv) "$name (private)" else name).setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(openApp()).setAutoCancel(true)
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL)
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(notifId++, b.build())
    }
}
