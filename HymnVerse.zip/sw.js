/*
 * HymnVerse Service Worker
 * ---------------------------------------------------------------------
 * The entire songbook database (every song, lyric, category and number)
 * is embedded directly inside index.html as JavaScript data — it is
 * never fetched separately from anywhere. That means caching this one
 * HTML file (plus the manifest and icons, for a proper installed-app
 * look) is *all* offline support requires: once cached, every songbook,
 * every lyric, and the Bible readers are available with zero network
 * requests.
 *
 * Bump CACHE_VERSION whenever index.html changes so returning users
 * automatically pick up the new copy instead of being stuck on an old
 * cached one.
 */
const CACHE_VERSION = 'hymnverse-cache-v0-28-2';
const SHELL_URL = './';

const CORE_ASSETS = [
  SHELL_URL,
  './manifest.json'
];
const ICON_ASSETS = [
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-mask-192.png',
  './icons/icon-mask-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_VERSION);
    // Core assets are required for the app to run at all — if these fail,
    // the install should fail loudly rather than silently leave a broken cache.
    await cache.addAll(CORE_ASSETS);
    // Icons only affect the installed home-screen icon; cache them
    // best-effort so one missing icon can never block the whole install.
    await Promise.all(ICON_ASSETS.map((url) => cache.add(url).catch(() => {})));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => k !== CACHE_VERSION).map((k) => caches.delete(k)));
    // Ask for persistent storage so the cached songbook is less likely to be
    // evicted under storage pressure. Best-effort — not every browser grants this.
    if (navigator.storage && navigator.storage.persist) {
      navigator.storage.persist().catch(() => {});
    }
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  // App-shell pattern: every navigation (typed URL, home-screen launch,
  // reload, or any unexpected path) is served from the cached
  // index.html instantly, with zero network dependency. If a
  // connection happens to be available, the cached copy is quietly
  // refreshed in the background for next time — that refresh never
  // delays or blocks this response.
  if (req.mode === 'navigate') {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE_VERSION);
      const cachedShell = await cache.match(SHELL_URL);
      if (cachedShell) {
        event.waitUntil(
          fetch(SHELL_URL).then((fresh) => {
            if (fresh && fresh.status === 200) return cache.put(SHELL_URL, fresh);
          }).catch(() => {})
        );
        return cachedShell;
      }
      // Nothing cached yet — this is the very first load, which must be online
      // once so the app (and its embedded songbook) can be saved for offline use.
      try {
        const fresh = await fetch(req);
        if (fresh && fresh.status === 200) cache.put(SHELL_URL, fresh.clone());
        return fresh;
      } catch (err) {
        return new Response(
          '<!doctype html><meta charset="utf-8"><body style="background:#0A2F2A;color:#F3EFE3;' +
          'font-family:sans-serif;padding:40px;text-align:center;">' +
          '<h2>HymnVerse needs one online visit first</h2>' +
          '<p>Connect once so the app and its songbook can be saved for offline use, then reopen it any time.</p>' +
          '</body>',
          { status: 200, headers: { 'Content-Type': 'text/html' } }
        );
      }
    })());
    return;
  }

  // Everything else (manifest, icons): cache-first, filling the cache on
  // first network fetch so later visits never need the network again.
  event.respondWith((async () => {
    const cache = await caches.open(CACHE_VERSION);
    const cached = await cache.match(req);
    if (cached) return cached;
    try {
      const fresh = await fetch(req);
      if (fresh && fresh.status === 200) cache.put(req, fresh.clone());
      return fresh;
    } catch (err) {
      return cached || Response.error();
    }
  })());
});
